#!/usr/bin/env node
/**
 * NOVA entry point (hosts run: node server.mjs).
 *
 * boot.mjs decides the role: fleet agent, or supervisor that keeps
 * nova-app.mjs alive and reloads it after an update.
 */
import "./boot.mjs";
