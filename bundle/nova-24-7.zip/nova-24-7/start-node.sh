#!/bin/sh
# شغّل هذا المجلد كـ"نود" ينضم للأسطول (بدون تعديل أي ملف).
: "${NOVA_SERVER:?حط عنوان الهاب: NOVA_SERVER=wss://hub.example.com/api/local-agent/ws}"
export NOVA_ROLE=node
export NOVA_AGENT_ID="${NOVA_AGENT_ID:-$(hostname)}"
exec node boot.mjs
