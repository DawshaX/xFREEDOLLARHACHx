#!/usr/bin/env node
/**
 * NOVA — "ليه النود مش بيتصل؟" تشخيص سريع.
 *   node diagnose.mjs                      # يختبر NOVA_SERVER من البيئة
 *   node diagnose.mjs wss://host/api/local-agent/ws
 */
import net from "node:net";
import tls from "node:tls";

const target = process.argv[2] || process.env.NOVA_SERVER || "ws://127.0.0.1:8080/api/local-agent/ws";
const m = /^(wss?):\/\/([^/]+)(\/.*)?$/i.exec(target);
if (!m) {
  console.error("✗ عنوان غير صالح:", target);
  process.exit(2);
}
const [, scheme, hostPort, pathPart = "/api/local-agent/ws"] = m;
const secure = scheme.toLowerCase() === "wss";
const [host, portRaw] = hostPort.split(":");
const port = Number(portRaw || (secure ? 443 : 80));
const httpBase = `${secure ? "https" : "http"}://${hostPort}`;

console.log("target:", target);
console.log("host  :", host, "port:", port, secure ? "(tls)" : "(plain)");

// 1) HTTP reachability of the same origin
try {
  const r = await fetch(`${httpBase}/api/health`, { signal: AbortSignal.timeout(8000) });
  console.log("① health:", r.status, (await r.text()).slice(0, 80));
} catch (e) {
  console.log("① health: فشل —", e.cause?.code || e.message);
}

// 2) raw TCP reachability
await new Promise((resolve) => {
  const s = net.connect({ host, port });
  s.setTimeout(8000, () => { console.log("② tcp   : timeout"); s.destroy(); resolve(); });
  s.once("connect", () => { console.log("② tcp   : مفتوح ✓"); s.destroy(); resolve(); });
  s.once("error", (e) => { console.log("② tcp   : فشل —", e.code); resolve(); });
});

// 3) the actual WebSocket upgrade, with the real status line
await new Promise((resolve) => {
  const socket = secure ? tls.connect({ host, port, servername: host }) : net.connect({ host, port });
  const send = () =>
    socket.write(
      `GET ${pathPart} HTTP/1.1\r\nHost: ${hostPort}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n` +
        "Sec-WebSocket-Key: MTIzNDU2Nzg5MGFiY2RlZg==\r\nSec-WebSocket-Version: 13\r\n\r\n",
    );
  if (secure) socket.once("secureConnect", send); else socket.once("connect", send);
  socket.setTimeout(9000, () => { console.log("③ upgrade: timeout"); socket.destroy(); resolve(); });
  socket.on("data", (d) => {
    console.log("③ upgrade:", d.toString("latin1").split("\r\n")[0]);
    socket.destroy();
    resolve();
  });
  socket.on("error", (e) => { console.log("③ upgrade: فشل —", e.code || e.message); resolve(); });
});

console.log("");
console.log("تفسير السطر ③:");
console.log("  101 Switching Protocols → كل حاجة تمام، النود هيتصل");
console.log("  502 / 504              → البروكسي مش واصل للتطبيق (جرّب ربط السب-دومين من جديد)");
console.log("  404                    → المسار غلط (لازم ينتهي بـ /api/local-agent/ws)");
console.log("  400                    → مفتاح الـhandshake غلط (باج في التشخيص نفسه، بلّغ)")
console.log("  ECONNRESET / timeout   → البورت مقفول من الشبكة اللي انت فيها (استخدم wss:// على دومين)");
