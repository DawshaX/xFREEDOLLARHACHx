#!/bin/sh
# NOVA + a free public HTTPS URL (Cloudflare quick tunnel — no account, no card).
# The app itself listens on $PORT/SERVER_PORT; the tunnel prints an
# https://<random>.trycloudflare.com address. The address changes only when
# this process restarts.
cd "$(dirname "$0")" || exit 1
PORT="${SERVER_PORT:-8080}"
export PORT
sh ./start.sh &
APP=$!
CT="$(dirname "$0")/cloudflared"
if [ ! -x "$CT" ]; then
  URL="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64"
  [ "$(uname -m)" = "aarch64" ] && URL="https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-arm64"
  echo "downloading cloudflared…"
  curl -fsSL "$URL" -o "$CT" && chmod +x "$CT" || echo "cloudflared download failed — app still runs locally on port $PORT"
fi
[ -x "$CT" ] && "$CT" tunnel --no-autoupdate --url "http://127.0.0.1:$PORT" &
wait $APP
