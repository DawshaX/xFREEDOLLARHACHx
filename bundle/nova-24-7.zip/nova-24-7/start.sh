#!/bin/sh
# NOVA — start (no install needed)
# PORT is taken from PORT or SERVER_PORT; the panel is served from ./public.
#
# The cd is load-bearing. A panel egg runs its startup command from /home/container
# (or whatever its workdir is), not from inside the bundle, so "sh app/start.sh"
# used to die with "Cannot find module '/home/container/boot.mjs'" while the files
# sat right there. Measured 2026-11-05 from /tmp before this line existed.
HERE="$(cd "$(dirname "$0")" && pwd)"
cd "$HERE" || exit 1
PARENT="$(dirname "$HERE")"
# ── TEST36 — الإقلاع من أي تخليط مجلدات (مقاس 2026-11-15) ─────────────────────
# المرآة الحية قالت boot.dir=/home/container (الباندل مفكوك في الجذر) بينما
# الREADME بيقول nova-24-7/ — فأمر التشغيل بيّت حسب مكان الفك وماتفتحش.
# القاعدة دلوقتي: لو boot.mjs مش جنب دي، دوّر جنبك (المجلد الجُوّاني أو الأب)
# ولو مالقيتش — اصرخ بالعربي على الكونسول بالفك الصح بدل «No such file» صامت.
if [ ! -f "$HERE/boot.mjs" ]; then
  if [ -f "$HERE/nova-24-7/boot.mjs" ]; then
    echo "[run] الملفات في $HERE/nova-24-7 — بنكمل من هناك"
    exec sh "$HERE/nova-24-7/run" "$@"
  fi
  if [ -f "$PARENT/boot.mjs" ]; then
    echo "[run] الملفات في $PARENT — بنكمل من هناك"
    exec sh "$PARENT/run" "$@"
  fi
  echo "[run] ✗ مافيش boot.mjs في $HERE ولا $HERE/nova-24-7 ولا $PARENT"
  echo "[run] الفك الصح: ازل الzip جوّه /home/container —"
  echo "[run]   unzip -o nova-24-7.zip -d /home/container"
  echo "[run] وبعدها أمر التشغيل (أي واحد فيهم بيشتغل):"
  echo "[run]   sh /home/container/run"
  echo "[run]   sh /home/container/nova-24-7/run"
  exit 1
fi
export NODE_ENV=production
export HOST=0.0.0.0
export NOVA_STATIC_DIR="$HERE/public"
[ -z "$NOVA_TOOLCHAIN_FETCH" ] && export NOVA_TOOLCHAIN_FETCH=1
[ -z "$NOVA_PROVISION_TOOLS" ] && export NOVA_PROVISION_TOOLS=1
[ -z "$NOVA_AUTO_UPDATE_MINUTES" ] && export NOVA_AUTO_UPDATE_MINUTES=5
export NOVA_MEMORY_FILE="$HERE/state/nova-memory.json"
export NOVA_JOBS_REL="$HERE/state/jobs"
export NOVA_PROGRAMS_FILE="$HERE/state/programs.json"
mkdir -p "$HERE/state/jobs"
# ── core dumps = قاتل القرص (مقاس 2026-11-11) ──────────────────────────────
# كل OOM crash بـSIGABRT كان بيكتب core.* على القرص: 8 ملفات بمجموع ~2.5GB
# (core.178 وحده 493MB) فجّروا حصة waifly وPterodactyl قتل السيرفر. القرص هنا
# ~2GB، فكور واحد كفيل يقفل السلوت. ulimit -c 0 بيوقف توليد أي core جديد لكل
# العمليات الفرعية (boot.mjs → التطبيق يرثان الحد)، وrm بيمسح اللي اتكتب قبل
# الإصلاح ده عند أول إقلاع — self-healing بلا تدخل يدوي.
ulimit -c 0 2>/dev/null || true
rm -f "$HERE"/core.* 2>/dev/null || true
# ── فضي المساحة قبل الإقلاع (مقاس 2026-11-15: waifly وقفت فوق الحصة 3GB/1.5GB) ──
# الإقلاع نفسه بيحتاج يكتب، فالتنضيف ده بيجري قبل أي node. القواعد كلها معلنة:
#   بقايا كالي الناقصة = زبالة دايمًا (الأصل سحابي على فرع kali-rootfs)
#   كالي كاملة + الفاضي < 250MB = مابتشتغلش في الحصة دي أصلًا — بتفضّى عشان السيرفر يقلع
#   backups: آخر نسخة بس بتفضل
#   لوج فوق 5MB = يتقص لـ1MB
#   .env.txt = نسخة مفاتيح مكررة جنب .env — خطر أمني قبل ما يكون مساحة
#   vendor الثقيلة تتشال بس لو الفاضي واقف (بتتنزل عند الطلب)
NOVA_CLEANED=0
for BASE in "$PARENT" "$HERE" /home/container; do
  [ -d "$BASE" ] || continue
  # بقايا كالي: ناقصة = تمسح دايمًا؛ كاملة بتفضل إلا لو الفاضي واقف تحت 250MB
  KR="$BASE/kali-rootfs"
  if [ -d "$KR" ]; then
    PKGS=0
    if [ -f "$KR/rootfs/var/lib/dpkg/status" ]; then
      PKGS=$(grep -c '^Package:' "$KR/rootfs/var/lib/dpkg/status" 2>/dev/null) || PKGS=0
    fi
    FREE_KB=$(df -Pk "$BASE" 2>/dev/null | awk 'NR==2{print $4}') || FREE_KB=999999
    if [ "${PKGS:-0}" -lt 400 ] || [ "${FREE_KB:-999999}" -lt 250000 ]; then
      KB=$(du -sk "$KR" 2>/dev/null | cut -f1) || KB=0
      rm -rf "$KR" 2>/dev/null || true
      NOVA_CLEANED=$((NOVA_CLEANED + ${KB:-0}))
      echo "[boot-clean] kali-rootfs (packages=${PKGS:-0}) اتبحتاج ${KB:-0}KB — الأصل سحابي على فرع kali-rootfs"
    fi
  fi
  # backups: آخر نسخة بس بتفضل
  if [ -d "$BASE/backups" ]; then
    for D in $(ls -1dt "$BASE"/backups/nova-backup-*/ 2>/dev/null | tail -n +2); do
      KB=$(du -sk "$D" 2>/dev/null | cut -f1) || KB=0
      rm -rf "$D" 2>/dev/null || true
      NOVA_CLEANED=$((NOVA_CLEANED + ${KB:-0}))
    done
  fi
  # بقايا الإنقاذ في /tmp
  for T in /tmp/nova-rescue-* /tmp/nova-backup-* /tmp/nova-state-* /tmp/nova-proot-static.*; do
    [ -e "$T" ] || continue
    KB=$(du -sk "$T" 2>/dev/null | cut -f1) || KB=0
    rm -rf "$T" 2>/dev/null || true
    NOVA_CLEANED=$((NOVA_CLEANED + ${KB:-0}))
  done
  # لوجات فوق 5MB تتقص لآخر 1MB
  for F in "$BASE"/logs/*.log "$BASE"/state/*.log; do
    [ -f "$F" ] || continue
    KB=$(du -sk "$F" 2>/dev/null | cut -f1) || KB=0
    if [ "${KB:-0}" -gt 5000 ]; then
      tail -c 1048576 "$F" > "$F.trim" 2>/dev/null && mv "$F.trim" "$F" 2>/dev/null || true
      NOVA_CLEANED=$((NOVA_CLEANED + KB - 1024))
    fi
  done
  # .env.txt — نسخة مفاتيح مش مفروض تقعد جنب .env أصلًا
  if [ -f "$BASE/.env.txt" ]; then
    rm -f "$BASE/.env.txt" 2>/dev/null || true
    echo "[boot-clean] .env.txt اتمسح — نسخة مفاتيح مكررة (خطر أمني مش مساحة)"
  fi
  # vendor الثقيلة — بس لو الفاضي واقف (بتتنزل عند الطلب الصريح)
  if [ -d "$BASE/vendor/bin" ] && [ "${FREE_KB:-999999}" -lt 250000 ]; then
    for H in amass nuclei trivy trufflehog osv-scanner gobuster; do
      if [ -f "$BASE/vendor/bin/$H" ]; then
        KB=$(du -sk "$BASE/vendor/bin/$H" 2>/dev/null | cut -f1) || KB=0
        rm -f "$BASE/vendor/bin/$H" 2>/dev/null || true
        NOVA_CLEANED=$((NOVA_CLEANED + ${KB:-0}))
      fi
    done
  fi
done
if [ "$NOVA_CLEANED" -gt 0 ]; then
  echo "[boot-clean] اتحرر ~$((NOVA_CLEANED / 1024))MB قبل الإقلاع — القواعد المعلنة فوق، state/ والذاكرة ماتمسّوش"
fi
FREE_NOW=$(df -Pk "$HERE" 2>/dev/null | awk 'NR==2{print $4}')
echo "[boot-clean] الفاضي بعد التنضيف: $((FREE_NOW / 1024))MB"
# ── الحلقة دي هي موضوع الملف ده كله ──────────────────────────────────────────
# boot.mjs بيراقب التطبيق، بس مافيش حاجة بتراقب boot.mjs نفسه. على بيضة
# Pterodactyl (Waifly) العملية اللي بتخلص هنا هي العملية الرئيسية للحاوية كلها،
# فموتها معناه السلوت بيتعلّم «offline» ومافيش حاجة بترجّعه: قِيس 2026-11-07 —
# 502 من 20:41Z لأكتر من تلات ساعات، وكل الإصلاحات اللي في العالم ما كانتش
# هتوصل غير بزرّار من صاحب الحساب. الحلقة دي بتحوّل «موت مؤقت» لقيام تلقائي.
#
# الزرّار الحقيقي بيفضل شغال: SIGTERM/INT من اللوحة بيتحوّل لـ stop نظيف بلا
# respawn، ولو التطبيق نفسه عايز ينام (state/NOVA_HALT) الحلقة بتسلم وتخرج.
NOVA_PID=""
NOVA_STOP=0
NOVA_TRIES=0
NOVA_CODE=0
trap 'NOVA_STOP=1; if [ -n "$NOVA_PID" ]; then kill -TERM "$NOVA_PID" 2>/dev/null; fi' TERM INT

# NOVA_RESPAWN_MIN/HEALTHY للتستات والاضطرار؛ الافتراضي محسوب على مكنة 300MB.
# (بنكتب $VAR بلا أقواس: أي dollar-brace جوه template literal بتاع JS بتتفسّر interp.)
NOVA_MIN_SLEEP="$NOVA_RESPAWN_MIN"
[ -z "$NOVA_MIN_SLEEP" ] && NOVA_MIN_SLEEP=2
NOVA_HEALTHY="$NOVA_RESPAWN_HEALTHY"
[ -z "$NOVA_HEALTHY" ] && NOVA_HEALTHY=300
NOVA_FAST="$NOVA_RESPAWN_FASTCRASH"
[ -z "$NOVA_FAST" ] && NOVA_FAST=60

while : ; do
  if [ -f "$HERE/state/NOVA_HALT" ]; then
    echo "[start] state/NOVA_HALT موجود — بنسلّم ومافيش إعادة تشغيل"
    exit 0
  fi
  NOVA_T0=$(date +%s)
  node boot.mjs &
  NOVA_PID=$!
  wait "$NOVA_PID"
  NOVA_CODE=$?
  NOVA_PID=""
  if [ "$NOVA_STOP" = 1 ]; then
    echo "[start] اتقفلت بأمر من اللوحة (SIGTERM) — مافيش إعادة تشغيل"
    exit 0
  fi
  NOVA_UP=$(( $(date +%s) - NOVA_T0 ))
  if [ "$NOVA_UP" -ge "$NOVA_HEALTHY" ]; then NOVA_TRIES=0; fi
  NOVA_TRIES=$((NOVA_TRIES + 1))
  NOVA_SLEEP=$NOVA_MIN_SLEEP
  if [ "$NOVA_TRIES" -ge 2 ]; then NOVA_SLEEP=4; fi
  if [ "$NOVA_TRIES" -ge 3 ]; then NOVA_SLEEP=8; fi
  if [ "$NOVA_TRIES" -ge 4 ]; then NOVA_SLEEP=16; fi
  if [ "$NOVA_TRIES" -ge 5 ]; then NOVA_SLEEP=30; fi
  if [ "$NOVA_TRIES" -ge 7 ]; then NOVA_SLEEP=60; fi
  if [ "$NOVA_UP" -lt 10 ] && [ "$NOVA_SLEEP" -lt "$NOVA_FAST" ]; then
    # أقل من 10 ثانية = الملفات نفسها مكسورة؛ الدوّر على طول بيحرق القرص والنت.
    NOVA_SLEEP="$NOVA_FAST"
  fi
  echo "[start] boot.mjs خرج بكود $NOVA_CODE بعد $NOVA_UP ثانية — إعادة تشغيل في $NOVA_SLEEP ثانية (محاولة $NOVA_TRIES)"
  sleep "$NOVA_SLEEP"
done

exit $NOVA_CODE
