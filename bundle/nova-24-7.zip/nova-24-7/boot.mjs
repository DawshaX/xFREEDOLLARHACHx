#!/usr/bin/env node
import { createRequire } from "node:module";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { readFileSync, existsSync } from "node:fs";

const HERE = dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);

// Panels that let you edit files but not variables: copy node.env.example to
// .env next to this file. Real environment variables always win.
const envFile = join(HERE, ".env");

/**
 * Read .env into an object. Called again for every child launch, so editing
 * .env from the panel file manager and asking for a restart is enough — the
 * container itself never has to be restarted. (Real environment variables set
 * by the host still win; this only fills the gaps.)
 */
const readEnvFile = () => {
  const out = {};
  try {
    for (const raw of readFileSync(envFile, "utf8").split(/\r?\n/)) {
      const line = raw.trim();
      if (!line || line.startsWith("#")) continue;
      const eq = line.indexOf("=");
      if (eq < 1) continue;
      out[line.slice(0, eq).trim()] = line.slice(eq + 1).trim().replace(/^["']|["']$/g, "");
    }
  } catch {
    /* no .env — nothing to merge */
  }
  return out;
};

/**
 * Keys that came from .env (as opposed to the host's own environment).
 * On reload those are refreshed: editing an existing key in .env must take
 * effect, otherwise "paste a new API key and restart" would silently keep the
 * old value. Host-provided variables (PORT, SERVER_PORT, …) are never
 * overridden.
 */
const ENV_FROM_FILE = new Set();

const loadEnvFile = () => {
  const parsed = readEnvFile();
  let n = 0;
  for (const [k, v] of Object.entries(parsed)) {
    const owned = ENV_FROM_FILE.has(k);
    if (!owned && k in process.env) continue; // the host wins for its own vars
    if (process.env[k] === v) continue;
    process.env[k] = v;
    ENV_FROM_FILE.add(k);
    n += 1;
  }
  return n;
};

{
  const n = loadEnvFile();
  if (existsSync(envFile)) console.log("[nova] loaded " + envFile + (n ? " (" + n + " vars)" : ""));
}

// Sensible defaults for any container: reachable from outside, panel served
// from this folder, memory kept next to the code.
process.env.HOST = process.env.HOST || "0.0.0.0";
process.env.NODE_ENV = process.env.NODE_ENV || "production";
process.env.NOVA_STATIC_DIR = process.env.NOVA_STATIC_DIR || join(HERE, "public");
process.env.NOVA_MEMORY_FILE = process.env.NOVA_MEMORY_FILE || join(HERE, "state", "nova-memory.json");
// الحزمة المحمولة = مكنة واحدة، بلا مدير، والمستخدم قال «يعرف يحمّل أدوات وكل حاجة».
// قبل كده كان لازم أحد يكتب NOVA_TOOLCHAIN_FETCH=1 بنفسه، فالمكنة الحيّة فضلت
// vendor/bin فيها فاضي رغم إن القرص قابل للكتابة (اتقاس). الافتراضي بقى: التنزيل
// مسموح، وNOVA_TOOLCHAIN_FETCH=0 يرجّع القفل.
process.env.NOVA_TOOLCHAIN_FETCH = process.env.NOVA_TOOLCHAIN_FETCH || "1";
process.env.NOVA_PROVISION_TOOLS = process.env.NOVA_PROVISION_TOOLS || "1";

// الفحص كل 15 دقيقة خلّى المكنة تردّ ببناء قِدْم بدقايق بعد الدمج (مقاس: PR #216
// اتدمج 00:12:49Z وسؤال المستخدم 00:14:17Z لسه طالع من البناء اللي قبله). 5 دقايق
// = 12 فحص/ساعة لـ api.github.com — جوه سقف الـ60/ساعة غير المصادق، ومعاه fallback
// الـHEAD على الأصل لو الـAPI رفض. NOVA_AUTO_UPDATE_MINUTES=15 يرجّع القديم.
// (ملاحظة للبنّاء: السطر ده جوه template literal — مفيش backticks هنا عمدًا.)
process.env.NOVA_AUTO_UPDATE_MINUTES = process.env.NOVA_AUTO_UPDATE_MINUTES || "5";

const explicit = String(process.env.NOVA_ROLE || "").trim().toLowerCase();
const role = explicit || (process.env.NOVA_SERVER ? "node" : "hub");

console.log("┌─ NOVA boot ─────────────────────────────────────────────");
console.log("│ role      : " + role + (explicit ? " (NOVA_ROLE)" : " (auto)"));
console.log("│ node      : " + process.version + " · " + process.platform + "/" + process.arch);
if (role === "node" || role === "agent") {
  console.log("│ hub       : " + (process.env.NOVA_SERVER || "(not set — using default)"));
  console.log("│ agent id  : " + (process.env.NOVA_AGENT_ID || "(hostname)"));
  console.log("└─────────────────────────────────────────────────────────");
  // The agent is CommonJS; load it through require so there is no ESM/CJS clash.
  require("./nova-agent.js");
} else {
  console.log("│ port      : " + (process.env.PORT || process.env.SERVER_PORT || "8080"));
  console.log("│ static    : " + process.env.NOVA_STATIC_DIR);
  console.log("└─────────────────────────────────────────────────────────");

  // ── supervisor ──────────────────────────────────────────────────────────
  // The real server (nova-app.mjs) runs as a CHILD of this process. Two wins:
  //   1. a deploy can replace nova-app.mjs and ask for a restart by touching
  //      state/.nova-restart — no panel button, no manual step;
  //   2. if the app ever crashes the container stay up and the app comes back.
  const { spawn } = await import("node:child_process");
  const { statSync, statfsSync, readFileSync, readdirSync, copyFileSync, mkdirSync, unlinkSync, writeFileSync, renameSync, existsSync } = await import("node:fs");
  const { get: httpGet } = await import("node:http");
  const MARK = join(HERE, "state", ".nova-restart");
  const ENTRY = join(HERE, "nova-app.mjs");

  const stamp = () => {
    try { return statSync(MARK).mtimeMs; } catch { return 0; }
  };

  let child = null;
  let leaving = false;
  // القياس 2026-11-11: التطبيق بيموت OOM بعد 25s بالظبط كل مرة — والموت ده
  // ينجح في خدمة /api/health لللحظات دي، فـ«healthy» بتبقى true ومؤقّت الإنقاذ
  // مش بينطلق أبدًا. الحارس الحقيقي: موت متتالي سريع (fastDeaths) = مرض.
  let firstFastDeathAt = 0;
  let mark = stamp();
  let vendorRunning = false;   // تنزيل الأدوات شغال؟ (ممنوع يتداخل مع إقلاع التطبيق)
  let fastDeaths = 0;          // موتات متتالية < 10s → crash-loop مثبت
  let bootDelays = 0;          // تأجيلات RAM متتالية — بعد 5 بنقلع على أي حال

  const cgroupMb = () => {
    // قياس حقيقي للحاوية (v2 ثم v1) — و«الحقيقي» معناه: نستبعد page cache.
    // القياس اللي علّمنا ده (2026-11-10): memory.current كان 420/460MB والإقلاع اتأجل
    // للأبد — بس الرقم ده بيعدّي inactive_file (كاش ملفات الأدوات 628MB اللي النظام
    // بيرميه فورًا تحت أي ضغط حقيقي). الضغط الصادق = anon memory مش المجموع الخام.
    // التفصيلة: v2 في memory.stat حقل «inactive_file»؛ v1 في memory.stat حقل
    // «total_inactive_file». لو مقدرناش نستبعده بنرجع للمجموع (أحسن من العمى).
    try {
      for (const [cur, max, stat, field] of [
        ["/sys/fs/cgroup/memory.current", "/sys/fs/cgroup/memory.max", "/sys/fs/cgroup/memory.stat", "inactive_file"],
        ["/sys/fs/cgroup/memory/memory.usage_in_bytes", "/sys/fs/cgroup/memory/memory.limit_in_bytes", "/sys/fs/cgroup/memory/memory.stat", "total_inactive_file"],
      ]) {
        if (existsSync(cur) && existsSync(max)) {
          const c = Number(readFileSync(cur, "utf8")), m = Number(readFileSync(max, "utf8"));
          if (!(isFinite(c) && isFinite(m) && m > 0 && m < 9007199254740991)) continue;
          let cache = 0;
          try {
            const st = readFileSync(stat, "utf8");
            const hit = st.match(new RegExp("^" + field + " (\d+)$", "m"));
            if (hit) cache = Number(hit[1]);
          } catch { /* stat مش مقروء — نكمل بالمجموع */ }
          const anon = Math.max(0, c - cache);
          return { usedMb: Math.round(anon / 1048576), rawMb: Math.round(c / 1048576), cacheMb: Math.round(cache / 1048576), maxMb: Math.round(m / 1048576) };
        }
      }
    } catch { /* بلا cgroup ظاهر — بنقول ماقسنا */ }
    return null;
  };

  const launch = () => {
    if (vendorRunning) { setTimeout(launch, 5000); return; } // التنزيل أولاً: مش هنضرب نفسنا
    // Re-read .env first: a key added in the panel takes effect on reload.
    const fresh = loadEnvFile();
    if (fresh) console.log("[supervisor] picked up " + fresh + " new env var(s) from .env");
    const mem = cgroupMb();
    if (mem && mem.usedMb > mem.maxMb * 0.88) {
      bootDelays += 1;
      // fail-open: القياس الكذاب (page cache محسوس كضغط) علّمنا إن التأجيل الأبدي
      // أسوأ من OOM محتمل — 502 دائمة أقسى على صاحب المنصة من إعادة تحت ضغط.
      // بعد 5 × 20s = 100s من «فوق 88%» بنقلع على أي حال: الـheap سقفه 200MB
      // والـOOM-killer لو تدخل هيبقى على قرار صادق مش على كاش.
      if (bootDelays >= 5) {
        console.log("[supervisor] RAM عالية بثبات (" + mem.usedMb + "/" + mem.maxMb + "MB anon · كاش " + mem.cacheMb + "MB خام " + mem.rawMb + "MB) — تأجل 100s. بنقلع على أي حال: 502 الأبدية أسوأ من ضغط مؤقت.");
        bootDelays = 0;
      } else {
        console.log("[supervisor] RAM " + mem.usedMb + "/" + mem.maxMb + "MB anon فوق 88% (خام " + mem.rawMb + " · كاش " + mem.cacheMb + "MB) — إقلاع مأجل 20s (" + bootDelays + "/5 قبل الإقلاع القسري)");
        setTimeout(launch, 20_000);
        return;
      }
    }
    const heap = process.env.NOVA_APP_HEAP_MB || "200"; // سقف V8 < سقف الـcgroup فالـGC يسبق الـSIGKILL
    const inherited = process.env.NODE_OPTIONS || "";
    const appNodeOptions = /max-old-space-size/.test(inherited) ? inherited : (inherited + " --max-old-space-size=" + heap).trim();
    bootDelays = 0;
    child = spawn(process.execPath, [ENTRY], {
      stdio: "inherit",
      env: Object.assign({}, process.env, { NOVA_SUPERVISED: "1", NODE_OPTIONS: appNodeOptions }),
    });
    const started = Date.now();
    child.on("exit", (code, signal) => {
      child = null;
      if (leaving) { process.exit(0); return; }
      const lived = Date.now() - started;
      if (lived < 10_000) {
        fastDeaths += 1;
        // backoff متصاعد: 3s → 6 → 12 → … → سقف 120s — الدوّار يهدى بدل ما يفرم الموارد
        const wait = Math.min(120_000, 3000 * Math.pow(2, Math.min(fastDeaths - 1, 5)));
        const m = cgroupMb();
        console.log("[supervisor] app exited (" + (signal || code) + ") after " + Math.round(lived / 1000) + "s — موت سريع رقم " + fastDeaths
          + (m ? " ، RAM الآن " + m.usedMb + "/" + m.maxMb + "MB" : "") + " — إعادة بعد " + Math.round(wait / 1000) + "s");
        if (fastDeaths === 8) {
          console.log("[supervisor] ⚠ crash-loop مثبت (8 موتات متتالية سريعة). الكود بيحني الضغط، بس لو وصلت هنا: امسح state/ أو سجّل تذكرة للمضيف — المُشرف هيكمّل بمحاولات متباعدة.");
        }
        setTimeout(launch, wait);
      } else {
        if (fastDeaths > 0) fastDeaths = 0;
        console.log("[supervisor] app exited (" + (signal || code) + ") after " + Math.round(lived / 1000) + "s — restarting");
        setTimeout(launch, 300);
      }
    });
    child.on("error", (err) => {
      console.log("[supervisor] could not start the app: " + err.message);
      setTimeout(launch, 5000);
    });
  };

  launch();

  /* ── الأيادي: المُشرف هو اللي بينزّل الأدوات، مش التطبيق ────────────────────
   * القياس اللي علّمنا ده مرتين في نفس الساعة (2026-11-07): التنزيل متحطّ في هوك
   * إقلاع التطبيق → الحاوية دخلت حلقة موت (nginx بيردّ 502 على كل حاجة، و
   * المُحدِّث جوه التطبيق فمافيش مخرج ذاتي)، لأن التطبيق رافع ~115–167MB RSS
   * والمرآة 219MB في حاوية سقفها 256MB. في المُشرف الابن بياخد 64MB والثانية
   * التانية التطبيق بيخدم — والأداة اللي محتاجها المحرك تبقى موجودة قبل الإقلاع
   * الجاي. مفيش تعطيل لأول طلب، ومفيش إعادة تشغيل.
   */
  // المحاولة الأولى بتحصل قبل ما أرشيف المرآة يخلص نشر أحيانًا (قِيس على
  // المكنة الحيّة 2026-11-08 01:01:54Z: «المرآة ما وصلتش: HTTP 404» — والثانية
  // 01:01:53Z كانت النشر نفسه). فالمكان ده بيعيد الناقص 3 مرات ب_backoff، وده
  // بيخلّي «5 أدوات من 16» حالة مؤقتة مش قدر.
  let toolchainTries = 0;
  const toolchainPass = () => {
    if (process.env.NOVA_TOOLCHAIN_AT_BOOT === "0") return;
    // التنزيل وقت الإقلاع بقى بموافقة صريحة (NOVA_TOOLCHAIN_AT_BOOT=1) — مابقناش
    // نعتمد على «المسار startsWith /home/container». والسبب مقيس على المكنة نفسها:
    // 01:01:54Z (404 لكل الـ16) و01:52:20Z — بعدها المكنة وقعت تاني و/api/health
    // رجّع 502 من 02:0xZ. الأب (التطبيق، 213MB وقت الإقلاع) والابن (المنزّل + tar
    // على أرشيف 296MB) في نفس سقف الـcgroup (460MB)، والقرص سلوت 1024MB مايلحقش
    // 296MB أرشيف + ~500MB أدوات. فالتنزيل يبقى بطلب POST /api/ops/tools/provision
    // والمكان فاضي (RSS وقت الهدوء متقاس: 92MB).
    if (process.env.NOVA_TOOLCHAIN_AT_BOOT !== "1") {
      console.log("[supervisor] التنزيل وقت الإقلاع متقفل افتراضيًا — NOVA_TOOLCHAIN_AT_BOOT=1 يفتحه، أو POST /api/ops/tools/provision");
      return;
    }
    const script = join(HERE, "scripts", "fetch-toolchain.mjs");
    if (!existsSync(script)) {
      console.log("[supervisor] مفيش scripts/fetch-toolchain.mjs في الحزمة — اتخطّيت");
      return;
    }
    const recordFile = join(HERE, "state", "toolchain-provision.json");
    const writeRecord = (rec) => {
      // نفس شكل ProvisionRecord في lib/ops/toolchain.ts — فاللوحة تقرّى محاولة
      // المُشرف زي ما تقرّى محاولة التطبيق بالظبط (مافيش "آخر محاولة" قديمة تخدع).
      try {
        mkdirSync(join(HERE, "state"), { recursive: true });
        const tmp = recordFile + "." + process.pid + ".tmp";
        writeFileSync(tmp, JSON.stringify(rec, null, 2));
        renameSync(tmp, recordFile);
      } catch { /* قرص مقفول — المحرّج لسه بيقرا المجلد نفسه */ }
    };
    const t0 = Date.now();
    let free = null;
    try {
      const fst = statfsSync(join(HERE, "state"));
      free = Math.round((fst.bsize * fst.bavail) / 1048576);
    } catch {
      free = null; // ماقدرناش نقيس — مانمنعش الحاجة، بس بنقول إننا ما قسناش
    }
    if (free !== null && free < 1500) {
      console.log("[supervisor] القرص الفاضي " + free + "MB تحت 1500MB — التنزيل اتخطّى");
      return;
    }
    const mem2 = cgroupMb();
    if (mem2 && mem2.usedMb > mem2.maxMb * 0.85) {
      console.log("[supervisor] RAM " + mem2.usedMb + "/" + mem2.maxMb + "MB فوق 85% — التنزيل اتأجل للدورة الجاية بدل ما يضرب الأب");
      return;
    }
    console.log("[supervisor] toolchain pass: بنكمّل vendor/bin من مِرر جيت هاب");
    vendorRunning = true;
    const cp = spawn(process.execPath, [script, "--into", join(HERE, "vendor", "bin"), "--json"], {
      cwd: HERE,
      stdio: ["ignore", "pipe", "pipe"],
      env: Object.assign({}, process.env, { NODE_OPTIONS: "--max-old-space-size=64" }),
    });
    let out = "";
    let err = "";
    cp.stdout.on("data", (d) => { out += d.toString(); });
    cp.stderr.on("data", (d) => { err += d.toString(); });
    const killer = setTimeout(() => { try { cp.kill("SIGKILL"); } catch { /* already gone */ } }, 900_000);
    cp.on("exit", (code, signal) => {
      clearTimeout(killer);
      vendorRunning = false;
      let doc = null;
      const i = out.lastIndexOf("{");
      for (let s2 = i; s2 >= 0; s2 -= 1) {
        try { doc = JSON.parse(out.slice(s2, out.lastIndexOf("}") + 1)); break; } catch { /* جرّب أقرب } */ }
      }
      if (doc) console.log("[supervisor] toolchain pass: " + doc.ok + "/" + doc.total + " جاهز في " + doc.into);
      else console.log("[supervisor] toolchain pass: مفيش JSON (exit " + (signal || code) + ") — " + err.slice(0, 160).replace(/\n/g, " "));
      writeRecord({
        at: new Date().toISOString(),
        ok: doc ? Number(doc.ok) > 0 : false,
        exitCode: typeof code === "number" ? code : null,
        ms: Date.now() - t0,
        into: join(HERE, "vendor", "bin"),
        installed: doc ? Number(doc.ok) || 0 : 0,
        total: doc ? Number(doc.total) || 16 : 16,
        results: doc && Array.isArray(doc.results) ? doc.results : [],
        ran: true,
        by: "supervisor",
        error: doc ? null : "no-json",
        reasonAr: doc ? null : "المُشرف شغّل المنزّل بس ماطلعش JSON (exit " + (signal || code) + ")",
      });
      const w = err.indexOf("::warning::");
      if (w >= 0) console.log("[toolchain] " + err.slice(w + 11, w + 260).split("\n")[0]);
      const total = doc ? Number(doc.total) : -1;
      const okN = doc ? Number(doc.ok) : -1;
      const missing = total > 0 ? total - okN : 1;
      if (missing > 0 && toolchainTries < 3) {
        const waitMin = [10, 30, 60][toolchainTries];
        toolchainTries += 1;
        console.log("[supervisor] فاضل " + missing + " أداة — هاعيد المحاولة بعد " + waitMin + " دقيقة (" + toolchainTries + "/3)");
        const t2 = setTimeout(toolchainPass, waitMin * 60000);
        if (t2.unref) t2.unref();
      }
    });
  };
  // 25 ثانية: أول طلب والـhealth يخلّصوا الأول، وبعدين الشبكة.
  const toolchainTimer = setTimeout(toolchainPass, 25000);
  toolchainTimer.unref?.();

  setInterval(() => {
    const now = stamp();
    if (now && now !== mark) {
      mark = now;
      console.log("[supervisor] restart requested — reloading the app");
      if (child) child.kill("SIGTERM");
    }
  }, 1000);

  // ── update watchdog ───────────────────────────────────────────────────────
  // After a self-update the new code must prove it can serve HTTP. If it does
  // not within 2 minutes, the previous bundle is restored from the backup the
  // updater recorded in state/.update-pending — a bad release can never leave
  // the server dead with nobody to fix it.
  const PENDING = join(HERE, "state", ".update-pending");
  const FAILED = join(HERE, "state", ".update-failed");

  const readPending = () => {
    try { return JSON.parse(readFileSync(PENDING, "utf8")); } catch { return null; }
  };

  const copyBack = (from) => {
    const skip = new Set([".env", ".env.txt", ".npm", "logs", "state", "node_modules"]);
    let n = 0;
    const walk = (src, dst) => {
      for (const entry of readdirSync(src, { withFileTypes: true })) {
        if (dst === HERE && skip.has(entry.name)) continue;
        const s = join(src, entry.name);
        const d = join(dst, entry.name);
        if (entry.isDirectory()) { mkdirSync(d, { recursive: true }); walk(s, d); }
        else { copyFileSync(s, d); n += 1; }
      }
    };
    walk(from, HERE);
    return n;
  };

  const healthy = (port) =>
    new Promise((resolve) => {
      const req = httpGet({ host: "127.0.0.1", port, path: "/api/health", timeout: 4000 }, (r) => {
        r.resume();
        resolve(r.statusCode >= 200 && r.statusCode < 500);
      });
      req.on("timeout", () => { req.destroy(); resolve(false); });
      req.on("error", () => resolve(false));
    });

  // لو مسار النسخة اللي في العلامة اتمسح (كونتير اتعاد قبل ما المُشرف يلحق)،
  // بنلقط أي نسخة موجودة: أجدد واحدة في <install>/backups وبعدين /tmp.
  // والمهم: لو مفيش نسخة خالص — نكمّل بالشغل اللي على الديسك ومانيقتلش
  // الطفل كل دقيقتين للأبد (اللي خلّى وايفي 502 من 04:13Z لـ04:25Z).
  const latestBackup = () => {
    for (const root of [join(HERE, "backups"), "/tmp"]) {
      let names = [];
      try {
        names = readdirSync(root).filter((n) => n.startsWith("nova-backup-")).sort();
      } catch {
        continue;
      }
      const dir = join(root, names[names.length - 1]);
      if (names.length > 0) {
        try {
          if (readdirSync(dir).length > 0) return dir;
        } catch {
          /* جرب الجذر اللي بعده */
        }
      }
    }
    return null;
  };

  let watchToken = 0;
  let rolledBackFor = "";
  const watch = (pending) => {
    const myToken = ++watchToken;
    const port = Number(process.env.PORT || process.env.SERVER_PORT || 8080);
    const verifyMs = Number(process.env.NOVA_UPDATE_VERIFY_SECONDS || 120) * 1000;
    const deadline = Date.now() + verifyMs;
    const tick = async () => {
      if (myToken !== watchToken) return;
      if (await healthy(port)) {
        console.log("[supervisor] update verified — new build is serving");
        try { unlinkSync(PENDING); } catch {}
        return;
      }
      if (Date.now() > deadline) {
        const token = String(pending.backup || "") + "|" + String(pending.to || "");
        if (rolledBackFor === token) return; // محاولة رجوع واحدة لكل تحديث
        const from = existsSync(pending.backup) ? pending.backup : latestBackup();
        if (!from) {
          rolledBackFor = token;
          console.log("[supervisor] no backup on disk (new path and /tmp both empty) — keeping the installed files and clearing the pending marker instead of killing the app in a loop");
          try {
            unlinkSync(PENDING);
            writeFileSync(FAILED, JSON.stringify({
              at: new Date().toISOString(),
              from: pending.from,
              to: pending.to,
              restored: 0,
              reason: "backup_missing",
            }, null, 2));
          } catch {}
          return;
        }
        rolledBackFor = token;
        console.log("[supervisor] new build never became healthy — rolling back from " + from);
        try {
          const files = copyBack(from);
          unlinkSync(PENDING);
          writeFileSync(FAILED, JSON.stringify({
            at: new Date().toISOString(),
            from: pending.from,
            to: pending.to,
            restored: files,
          }, null, 2));
          console.log("[supervisor] restored " + files + " files from " + from);
        } catch (e) {
          console.log("[supervisor] rollback FAILED: " + (e && e.message));
        }
        if (child) child.kill("SIGTERM"); else launch();
        return;
      }
      setTimeout(tick, 3000);
    };
    setTimeout(tick, 4000);
  };

  // ── الإنقاذ الذاتي للمُشرف ─────────────────────────────────────────────
  // الفخ اللي علّمنا ده جاي (2026-11-10): بوابة الرام أجّلت الإقلاع للأبد ⇒
  // 502 متواصلة، والمُحدِّث جوه التطبيق — والتطبيق مش شغال ⇒ مافيش إصلاح بيوصل.
  // الحلقة دي بتقفل الفخ: لو /api/health فضل ميّت 4+ دقائق ومفيش طفل شغال،
  // المُشرف نفسه بينزّل أحدث nova-24-7.zip من GitHub Releases، بياخد نسخة أمان،
  // بيستبدل الملفات (متخطّيًا state/ و .env)، بيسجّل .update-pending (عشان الـ
  // watchdog فوق يرجّع لو الجديد ما صحّش)، وبيخرج بكود 42 ⇒ حلقة start.sh تعيد
  // تشغيل boot.mjs بالنسخة الجديدة. التعطيل: NOVA_RESCUE_OFF=1.
  let downSince = 0;
  let rescuing = false;
  let lastRescueTry = 0;
  const rescuePort = Number(process.env.PORT || process.env.SERVER_PORT || 8080);
  const rescueUrl = process.env.NOVA_UPDATE_ASSET_URL
    || "https://github.com/DawshaX/xFREEDOLLARHACHx/releases/download/nova-portable/nova-24-7.zip";

  const rescueSwap = async () => {
    console.log("[supervisor] التطبيق ميّت 4+ دقائق ومفيش طفل — إنقاذ ذاتي: بنزّل أحدث حزمة وبستبدل نفسي");
    const res = await fetch(rescueUrl, { redirect: "follow", signal: AbortSignal.timeout(180_000) });
    if (!res.ok) throw new Error("asset " + res.status);
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length < 1_000_000) throw new Error("asset صغير أوي (" + buf.length + "B) — مش هنستبدل بحاجة مشكوك فيها");
    const stamp2 = Date.now();
    const zipPath = "/tmp/nova-rescue-" + stamp2 + ".zip";
    const outDir = "/tmp/nova-rescue-" + stamp2;
    writeFileSync(zipPath, buf);
    await new Promise((resolve, reject) => {
      // python3 موجود فعلًا على المكنة (live-update.py بيشتغل عليه)
      const py = spawn("python3", ["-c", "import zipfile,sys; zipfile.ZipFile(sys.argv[1]).extractall(sys.argv[2])", zipPath, outDir], { stdio: "inherit" });
      py.on("exit", (c) => (c === 0 ? resolve() : reject(new Error("unzip code " + c))));
      py.on("error", reject);
    });
    try { unlinkSync(zipPath); } catch {}
    // الأرشيف أحيانًا بيبقى جواه فولدر رئيسي — بنلاقي اللي فيه nova-app.mjs
    let root = outDir;
    if (!existsSync(join(root, "nova-app.mjs"))) {
      for (const s of readdirSync(root, { withFileTypes: true })) {
        const cand = join(root, s.name);
        if (s.isDirectory() && existsSync(join(cand, "nova-app.mjs"))) { root = cand; break; }
      }
    }
    if (!existsSync(join(root, "nova-app.mjs"))) throw new Error("الأرشيف مفيهوش nova-app.mjs — أبطل الإنقاذ");
    // نسخة أمان من الحالة الحالية قبل الاستبدال (نفس قواعد تخطّي الرول-باك + backups)
    const bk = join(HERE, "backups", "nova-backup-" + new Date().toISOString().replace(/[:.]/g, "-"));
    mkdirSync(bk, { recursive: true });
    const skipBk = new Set([".env", ".env.txt", ".npm", "logs", "state", "node_modules", "backups"]);
    const toBackup = (sd, dd) => {
      for (const entry of readdirSync(sd, { withFileTypes: true })) {
        if (sd === HERE && skipBk.has(entry.name)) continue;
        const s2 = join(sd, entry.name), d2 = join(dd, entry.name);
        if (entry.isDirectory()) { mkdirSync(d2, { recursive: true }); toBackup(s2, d2); }
        else copyFileSync(s2, d2);
      }
    };
    toBackup(HERE, bk);
    writeFileSync(PENDING, JSON.stringify({ at: new Date().toISOString(), from: "rescue", to: rescueUrl, backup: bk }, null, 2));
    const files = copyBack(root);
    console.log("[supervisor] rescue بدّل " + files + " ملف من آخر إصدار — خروج بكود 42 عشان حلقة start.sh ترجّع النسخة الجديدة");
    process.exit(42);
  };

  const rescueTick = async () => {
    if (process.env.NOVA_RESCUE_OFF === "1" || rescuing || vendorRunning) { downSince = 0; return; }
    // flap أولاً: 3+ موتات سريعة في 120s = التطبيق بيلف على ذيله — الإنقاذ مش
    // بيستنى صحّة غائبة، بيرأي المرض.
    if (fastDeaths >= 3) {
      if (Date.now() - lastRescueTry < 300_000) return; // كل 5 دقايق سقف
      rescuing = true; lastRescueTry = Date.now();
      console.log("[supervisor] crash-loop مثبت (" + fastDeaths + " موتات متتالية سريعة) — إنقاذ ذاتي بيستبدل الحزمة");
      try { await rescueSwap(); }
      catch (e) { console.log("[supervisor] rescue فشل: " + (e && e.message)); }
      rescuing = false;
      return;
    }
    if (child) { downSince = 0; return; }
    if (await healthy(rescuePort)) { downSince = 0; return; }
    if (!downSince) { downSince = Date.now(); return; }
    if (Date.now() - downSince < 240_000) return;   // 4 دقائق موت متواصل قبل التدخل
    if (Date.now() - lastRescueTry < 900_000) return; // محاولة كل ربع ساعة سقف — مش فرم
    rescuing = true; lastRescueTry = Date.now();
    try { await rescueSwap(); }
    catch (e) { console.log("[supervisor] rescue فشل: " + (e && e.message)); }
    rescuing = false;
  };
  setInterval(() => { void rescueTick(); }, 30_000).unref?.();

    const pendingAtBoot = readPending();
  if (pendingAtBoot && pendingAtBoot.backup) {
    console.log("[supervisor] an update is pending verification (from " + pendingAtBoot.from + ")");
    watch(pendingAtBoot);
  }

  // A later update (started by the app itself) is picked up on the next reload.
  let mark2 = 0;
  setInterval(() => {
    const p = readPending();
    if (p && p.backup) {
      try {
        const m = statSync(PENDING).mtimeMs;
        if (m !== mark2) { mark2 = m; watch(p); }
      } catch {}
    }
  }, 5000);

  for (const sig of ["SIGTERM", "SIGINT"]) {
    process.on(sig, () => {
      leaving = true;
      if (child) child.kill(sig);
      else process.exit(0);
    });
  }
}
