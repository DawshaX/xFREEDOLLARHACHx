#!/usr/bin/env node
/**
 * NOVA — universal entry point.
 *
 *   node index.js            → picks the role from the environment
 *   NOVA_SERVER=wss://…      → fleet node
 *   (nothing set)            → hub
 *
 * Works on panels that run a fixed start command such as
 *   /start.sh  →  npm install  →  node <Main file (Node.js)>
 * Set "Main file (Node.js)" to:  index.js
 */
console.log("[nova] entry index.js · " + process.version + " · " + process.platform + "/" + process.arch);

import("./boot.mjs").catch((err) => {
  console.error("[nova] boot failed:", err && (err.stack || err.message || err));
  process.exit(1);
});
