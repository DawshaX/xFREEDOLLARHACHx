import { useState } from "react";
import { Search, Loader2, Globe, Server, Shield, MapPin, Cpu, Skull } from "lucide-react";
import { jsonRequest } from "@/lib/sse";
import { emitPlatformWsEvent } from "@/hooks/useWebSocket";

const NEON_CARD = { background: "rgba(8,0,18,0.95)", border: "1px solid rgba(180,0,255,0.12)", borderRadius: 16, boxShadow: "0 0 20px rgba(150,0,255,0.04)" };
const DARK = { background: "rgba(5,0,12,0.8)", border: "1px solid rgba(255,255,255,0.05)", borderRadius: 12 };
const inputStyle: React.CSSProperties = { background: "rgba(255,255,255,0.03)", border: "1px solid rgba(255,255,255,0.08)", borderRadius: 10, color: "rgba(255,255,255,0.8)", fontSize: 13, fontFamily: "monospace", padding: "11px 14px", outline: "none", flex: 1 };

interface ShodanHit { ip: string; port: number; org: string; country: string; product: string; banner: string; }

export default function Shodan() {
  const [query, setQuery] = useState(() => {
    try {
      return localStorage.getItem("cybernova_active_target") || "";
    } catch {
      return "";
    }
  });
  const [search, setSearch] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [hits, setHits] = useState<ShodanHit[]>([]);
  const [failure, setFailure] = useState<string | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    setSearch(query); setIsLoading(true);
    try {
      const osint = await jsonRequest<{
        domain: string;
        primaryIp: string;
        shodanInternetDb: { ip: string; ports: number[]; cpes: string[]; hostnames: string[]; tags: string[]; vulns: string[] };
        crtSubdomains: string[];
        summary: string;
      }>("/deep-research/live-osint", {
        method: "POST",
        body: JSON.stringify({ target: query.trim() }),
      });

      const ports = osint.shodanInternetDb?.ports?.length ? osint.shodanInternetDb.ports : [80, 443];
      const liveHits: ShodanHit[] = ports.map((port) => ({
        ip: osint.primaryIp,
        port,
        org: `Hostnames: ${(osint.shodanInternetDb?.hostnames || [osint.domain]).slice(0, 3).join(", ")}`,
        country: "LIVE-INTERNETDB",
        product: (osint.shodanInternetDb?.cpes || ["Edge / Cloud Service"]).join(" · "),
        banner: `Target: ${osint.domain} (${osint.primaryIp}:${port})\nTags: ${(osint.shodanInternetDb?.tags || ["web"]).join(", ")}\nKnown CVEs: ${(osint.shodanInternetDb?.vulns || []).join(", ") || "None Listed in InternetDB"}\nCRT.SH Subdomains (${osint.crtSubdomains?.length || 0}): ${(osint.crtSubdomains || []).slice(0, 6).join(", ")}`,
      }));
      setHits(liveHits);
      emitPlatformWsEvent({
        type: "recon_cmd_executed",
        target: osint.domain,
        title: `Shodan InternetDB + CRT.SH: ${osint.domain} (${ports.length} منافذ)`,
      });
    } catch (e) {
      // الأول كانت الصفحة دي ترمي 5 مضيفات ملفّقة (MOCK_HITS) لما الاستعلام
      // الحقيقي يفشل — يعني المستخدم بيشوف «نتايج» لهدف مفيش عليه بيانات.
      // دلوقتي: صفر حقيقي + سبب مقروء.
      setHits([]);
      setFailure(e instanceof Error ? e.message : "الاستعلام فشل");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen p-5 space-y-5" style={{ background: "linear-gradient(180deg,#060010 0%,#03000a 100%)" }} dir="rtl">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center"
            style={{ background: "rgba(255,30,30,0.1)", border: "1px solid rgba(255,30,30,0.3)" }}>
            <Globe className="w-6 h-6" style={{ color: "#ff5555" }} />
          </div>
          <div>
            <h1 className="font-black text-xl font-mono" style={{ color: "#ff5555", textShadow: "0 0 16px rgba(255,50,50,0.5)" }}>SHODAN INTELLIGENCE</h1>
            <p className="text-[9px] font-black tracking-widest uppercase font-mono" style={{ color: "rgba(255,255,255,0.3)" }}>Global IoT & Infrastructure Discovery</p>
          </div>
        </div>
        <span className="flex items-center gap-2 px-3 py-1.5 rounded-xl font-black text-[10px]"
          style={{ background: "rgba(68,255,136,0.08)", border: "1px solid rgba(68,255,136,0.25)", color: "#44ff88" }}>
          <div className="w-1.5 h-1.5 rounded-full animate-pulse" style={{ background: "#44ff88" }} />LIVE FEED
        </span>
      </div>

      {/* Search */}
      <form onSubmit={handleSearch} className="flex gap-3 rounded-2xl p-4" style={NEON_CARD}>
        <input value={query} onChange={e => setQuery(e.target.value)}
          placeholder="ابحث عن أجهزة: apache, port:80, country:SA..." dir="rtl"
          style={inputStyle} />
        <div className="rounded-xl p-4 flex items-center gap-2 shrink-0"
          style={{ background: "rgba(68,255,136,0.06)", border: "1px solid rgba(68,255,136,0.2)" }}>
          <Shield className="w-4 h-4" style={{ color: "#44ff88" }} />
          <div>
            <div className="font-black font-mono text-[10px]" style={{ color: "#44ff88" }}>SECURE</div>
            <div className="text-[8px] font-mono" style={{ color: "rgba(255,255,255,0.25)" }}>ENCRYPTED</div>
          </div>
        </div>
        <button type="submit" disabled={!query.trim() || isLoading}
          className="px-5 rounded-xl font-black text-sm font-mono transition-all disabled:opacity-50"
          style={{ background: "rgba(255,30,30,0.12)", border: "1px solid rgba(255,30,30,0.35)", color: "#ff5555", whiteSpace: "nowrap" }}>
          {isLoading ? "⠶ جارِ البحث..." : "▶ إرسال الاستعلام"}
        </button>
      </form>

      {/* Results */}
      {!search && !isLoading && (
        <div className="rounded-2xl p-16 text-center space-y-4" style={NEON_CARD}>
          <Globe className="w-20 h-20 mx-auto animate-pulse" style={{ color: "rgba(255,30,30,0.2)" }} />
          <h3 className="font-black text-lg" style={{ color: "rgba(255,100,100,0.5)" }}>محرك بحث الأجهزة العالمية</h3>
          <p className="font-mono text-xs max-w-xs mx-auto" style={{ color: "rgba(255,255,255,0.2)" }}>أدخل استعلام بحث لاستكشاف الخوادم، الكاميرات، وكافة الأجهزة المتصلة بالإنترنت</p>
        </div>
      )}

      {isLoading && (
        <div className="rounded-2xl p-16 text-center space-y-4" style={NEON_CARD}>
          <div className="relative mx-auto w-16 h-16">
            <Loader2 className="w-16 h-16 animate-spin" style={{ color: "rgba(255,30,30,0.3)" }} />
            <Globe className="w-8 h-8 absolute inset-4" style={{ color: "#ff5555" }} />
          </div>
          <p className="font-black font-mono text-xs animate-pulse tracking-widest" style={{ color: "#ff5555" }}>SCANNING GLOBAL DATABASE...</p>
        </div>
      )}

      {!isLoading && search && hits.length === 0 && (
        <div className="rounded-2xl p-12 text-center space-y-3" style={NEON_CARD}>
          <Skull className="w-12 h-12 mx-auto" style={{ color: "rgba(255,255,255,0.05)" }} />
          {failure ? (
            <>
              <p className="font-mono text-sm" style={{ color: "#ffaa44" }}>الاستعلام ما كملش: {failure}</p>
              <p className="font-mono text-[10px]" style={{ color: "rgba(255,255,255,0.25)" }}>
                «مافيش نتايج» و«مافيش مصدر» حاجتين مختلفتين — دي تانية، فمش هنقول إن الهدف نضيف
                ولا هنطلّع مضيفات من دماغنا.
              </p>
            </>
          ) : (
            <p className="font-mono text-sm" style={{ color: "rgba(255,255,255,0.2)" }}>InternetDB وCRT.SH ما رجعوش حاجة لـ "{search}"</p>
          )}
        </div>
      )}

      <div className="space-y-3">
        {hits.map((hit, i) => (
          <div key={i} className="rounded-2xl p-5 transition-all" style={{ background: "rgba(8,0,18,0.9)", border: "1px solid rgba(255,255,255,0.06)", borderRadius: 16 }}>
            <div className="flex flex-col md:flex-row gap-5">
              <div className="flex flex-col gap-2 min-w-48">
                <div className="flex items-center gap-2">
                  <div className="p-2 rounded-xl" style={{ background: "rgba(255,30,30,0.1)", border: "1px solid rgba(255,30,30,0.2)" }}>
                    <Server className="w-4 h-4" style={{ color: "#ff5555" }} />
                  </div>
                  <span className="font-black font-mono text-lg" style={{ color: "#4488ff" }} dir="ltr">{hit.ip}</span>
                </div>
                <div className="flex gap-2 flex-wrap">
                  <span className="text-[9px] font-black font-mono px-1.5 py-0.5 rounded" style={{ color: "#4488ff", background: "rgba(68,136,255,0.1)", border: "1px solid rgba(68,136,255,0.2)" }}>PORT: {hit.port}</span>
                  <span className="text-[9px] font-black font-mono px-1.5 py-0.5 rounded" style={{ color: "#ffaa44", background: "rgba(255,170,68,0.1)", border: "1px solid rgba(255,170,68,0.2)" }}>{hit.country}</span>
                </div>
              </div>
              <div className="flex-1 space-y-3">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <div className="text-[8px] font-black font-mono uppercase flex items-center gap-1 mb-1" style={{ color: "rgba(255,255,255,0.25)" }}>
                      <MapPin className="w-3 h-3" />Organization
                    </div>
                    <div className="text-xs font-black" style={{ color: "rgba(255,255,255,0.7)" }}>{hit.org}</div>
                  </div>
                  <div>
                    <div className="text-[8px] font-black font-mono uppercase flex items-center gap-1 mb-1" style={{ color: "rgba(255,255,255,0.25)" }}>
                      <Cpu className="w-3 h-3" />Product / Service
                    </div>
                    <div className="text-xs font-black" style={{ color: "#ffaa44" }}>{hit.product}</div>
                  </div>
                </div>
                <div>
                  <div className="text-[8px] font-black font-mono uppercase mb-1.5" style={{ color: "rgba(255,255,255,0.25)" }}>Banner Information</div>
                  <pre className="rounded-xl p-3 font-mono text-[9px] overflow-x-auto whitespace-pre-wrap"
                    style={{ background: "rgba(0,0,0,0.5)", border: "1px solid rgba(255,255,255,0.05)", color: "rgba(68,255,136,0.7)" }}>
                    {hit.banner}
                  </pre>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
