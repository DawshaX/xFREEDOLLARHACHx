/**
 * NOVA — Agent Core (plan → execute → explain)
 * ────────────────────────────────────────────
 * One loop, two brains:
 *   • LLM brain  — when Ollama or a free-tier key is reachable, the model writes a
 *                  JSON plan (which tools + args) and later explains the results.
 *   • Heuristic brain — deterministic Arabic/English intent router used when no
 *                  model is reachable. It executes the SAME real tools, so the
 *                  agent keeps working fully offline (GitHub Pages included).
 *
 * Everything is streamed as structured events so the UI can show the agent
 * thinking, calling a tool, and reading its output live.
 */

import { NOVA_SYSTEM_PROMPT, NOVA_SYSTEM_PROMPT_SHORT } from "./persona";
import {
  AGENT_TOOLS,
  AGENT_TOOL_NAMES,
  runAgentTool,
  toolCatalogueForPrompt,
  extractTarget,
  type ToolRunResult,
} from "./tools";
import { llmComplete, extractJson } from "./llm";
import { saveMemory, getAllMemories } from "../../routes/memory";
import { remember, memoryContextFor, memoryStats, initMemory } from "./memory-store";
import { getMissionsState, recordMissionCommand } from "../standalone-api";
import { broadcastEvent } from "../ws-hub";
import { broadcastLiveEvent } from "./../../routes/live-events";
import { getConnectedAgentList } from "../../routes/local-agent";

export type AgentEvent =
  | { type: "ready"; sessionId: string; mode: "llm" | "heuristic"; provider: string; model: string; tools: number }
  | { type: "thought"; text: string }
  | { type: "plan"; steps: Array<{ tool: string; args: Record<string, unknown> }> }
  | { type: "tool_call"; id: string; name: string; title: string; args: Record<string, unknown>; risk: string }
  | { type: "tool_result"; id: string; name: string; ok: boolean; summary: string; ms: number; dataPreview: string }
  | { type: "confirm_required"; id: string; name: string; title: string; args: Record<string, unknown>; risk: string; reason: string }
  | { type: "delta"; text: string }
  | { type: "memory"; id: string; title: string }
  | { type: "done"; sessionId: string; mode: string; toolCount: number; ms: number; provider: string }
  | { type: "error"; message: string };

export interface AgentRunOptions {
  sessionId?: string;
  message: string;
  history?: Array<{ role: "user" | "assistant"; content: string }>;
  emit: (event: AgentEvent) => void;
  /** Force the deterministic brain (used by tests / air-gapped mode). */
  forceHeuristic?: boolean;
  maxSteps?: number;
  /**
   * Tools the human has already approved for this turn. Anything that declares
   * `risk: "sensitive"` (running commands on a real machine, killing processes…)
   * is NOT executed until its name shows up here, so the chat can never touch a
   * connected box by surprise — it must ask first and be told "yes".
   */
  approved?: string[];
  /** Require an explicit approval gate for tools that actively interact with targets. */
  requireApprovalForActive?: boolean;
}

interface PlannedStep {
  tool: string;
  args: Record<string, unknown>;
}

export interface AgentRunResult {
  mode: "llm" | "heuristic";
  provider: string;
  toolsUsed: string[];
  reply: string;
  ms: number;
}

/* ── context ─────────────────────────────────────────────────────────────── */

/** Compact, failure-proof summary of the connected machines. */
function safeFleetSummary(): string {
  try {
    const agents = getConnectedAgentList();
    if (agents.length === 0) return "لا يوجد (شغّل nova-agent.js على أي جهاز لربطه)";
    return `${agents.length} جهاز — ${agents
      .slice(0, 6)
      .map((a) => `${a.hostname}(${a.platform})`)
      .join(", ")}`;
  } catch {
    return "غير متاح";
  }
}

/**
 * Everything NOVA knows before it answers: live platform state + the durable
 * long-term memory (ranked against the current question and target).
 */
function buildContextBlock(query = ""): string {
  const missions = getMissionsState();
  const active = missions[0];
  const stats = memoryStats();
  const longTerm = memoryContextFor(query, active?.target ?? undefined, 8);
  const fleet = safeFleetSummary();
  return [
    `# سياق المنصة الآن`,
    `- الهدف النشط: ${active?.target ?? "غير محدد"} (${active?.name ?? "—"})`,
    `- الأجهزة المتصلة الآن: ${fleet}`,
    `- نتائج مسجلة في المهمة: ${active?.findings.length ?? 0}`,
    `- ذاكرتك طويلة الأمد: ${stats.total} ذكرى (${stats.pinned} مثبتة) — تفضل بعد إعادة التشغيل`,
    longTerm || "# الذاكرة طويلة الأمد فارغة حتى الآن",
  ].join("\n");
}

/* ── heuristic planner (works with zero models) ──────────────────────────── */

const FREE_COMPUTE_REQUEST =
  /(?:ابحث|بحث|تبحث|دور|دوّر|شوف|search|find|look up).*(?:النت|الويب|الإنترنت|انترنت|أجهزة|اجهزة|سيرفر|سيرفرات|استضافة|حوسبة|cloud|compute|free|مجاني)|(?:أجهزة|اجهزة|سيرفرات|استضافة|حوسبة|cloud|compute).*(?:مجاني|مجانية|free|النت|الويب|الإنترنت)/i;
const BUG_BOUNTY_PROGRAM_SEARCH =
  /(?:hackerone|هاكر\s*وان|bug\s*bounty).{0,80}(?:برنامج|program|scope|policy|نطاق)|(?:برنامج|program|scope|policy|نطاق).{0,80}(?:hackerone|هاكر\s*وان|bug\s*bounty)/i;

const INTENT: Array<{ test: RegExp; tools: (msg: string) => PlannedStep[] }> = [
  {
    test: /(?:نطاقات فرعية|subdomains?|subdomain)/i,
    tools: (msg) => {
      const host = extractTarget(msg);
      return host ? [{ tool: "subdomain_enum", args: { domain: host } }] : [];
    },
  },
  {
    test: /CVE-\d{4}-\d{4,7}/i,
    tools: (msg) => [{ tool: "cve_lookup", args: { cveId: (msg.match(/CVE-\d{4}-\d{4,7}/i) ?? [""])[0] } }],
  },
  {
    test: /(?:منافذ|بورت|ports?)/i,
    tools: (msg) => {
      const host = extractTarget(msg);
      return host ? [{ tool: "port_scan", args: { host } }] : [];
    },
  },
  {
    test: /(?:شهادة|ssl|tls|certificate)/i,
    tools: (msg) => {
      const host = extractTarget(msg);
      return host ? [{ tool: "tls_audit", args: { host } }] : [];
    },
  },
  {
    test: /(?:ترويسات|headers?|hsts|csp)/i,
    tools: (msg) => {
      const host = extractTarget(msg);
      return host ? [{ tool: "http_headers_audit", args: { host } }] : [];
    },
  },
  {
    test: /(?:افحص|فحص|استطلاع|recon|scan|حلل|analyse|analyze)/i,
    tools: (msg) => {
      const host = extractTarget(msg);
      if (!host) return [];
      const steps: PlannedStep[] = [
        { tool: "set_active_target", args: { target: host } },
        { tool: "recon_target", args: { target: host } },
      ];
      if (/(?:منافذ|بورت|ports?)/i.test(msg)) steps.push({ tool: "port_scan", args: { host } });
      if (/(?:نطاقات|subdomain)/i.test(msg)) steps.push({ tool: "subdomain_enum", args: { domain: host } });
      return steps;
    },
  },
  {
    test: /(?:exploit|poc|استغلال)/i,
    tools: (msg) => [{ tool: "exploit_search", args: { query: cleanQuery(msg) } }],
  },
  {
    test: /github/i,
    tools: (msg) => [{ tool: "github_search", args: { query: cleanQuery(msg) } }],
  },
  {
    test: /(?:ثغرات|ثغرة|vulnerab|cve)/i,
    tools: (msg) => BUG_BOUNTY_PROGRAM_SEARCH.test(msg)
      ? []
      : [{ tool: "vuln_search", args: { keyword: cleanQuery(msg), limit: 8 } }],
  },
  {
    test: /(?:أدوات|ادوات|kali|أداة|tool)/i,
    tools: (msg) => [{ tool: "kali_toolbox", args: { query: cleanQuery(msg), target: extractTarget(msg) ?? undefined } }],
  },
  {
    // Research questions about free compute need web search; a fleet snapshot
    // alone cannot answer what providers currently offer.
    test: FREE_COMPUTE_REQUEST,
    tools: (msg) => {
      const query = /(?:metasploit|ميتا.?سبوليت)/i.test(msg)
        ? "free cloud compute to run Metasploit legally with persistent storage, public network access, and provider terms"
        : "free cloud compute and VPS providers free tier limits persistent storage";
      return [{ tool: "web_search", args: { query, limit: 6 } }, { tool: "fleet_list", args: {} }];
    },
  },
  {
    test: /(?:ابحث|بحث|تبحث|دور|دوّر|شوف|search|find|look up).*(?:النت|علي النت|على النت|الويب|الإنترنت|انترنت|hackerone|هاكر\s*وان|bug\s*bounty|برنامج.*(?:ثغرات|مكافآت))|(?:hackerone|هاكر\s*وان|bug\s*bounty).*(?:برنامج|ابحث|بحث|دور|شوف|find|search)/i,
    tools: (msg) => {
      if (FREE_COMPUTE_REQUEST.test(msg)) return [];
      const query = BUG_BOUNTY_PROGRAM_SEARCH.test(msg)
        ? "HackerOne public bug bounty programs scope assets rewards policy"
        : msg.slice(0, 180);
      return [{ tool: "web_search", args: { query, limit: 6 } }];
    },
  },
  {
    // Machine availability questions are answered from the live fleet snapshot.
    // Commands still go through fleet_exec and its explicit approval gate.
    test: /(?:الأجهزة|الاجهزة|أجهزة|اجهزة|الماكينات|ماكينات|devices?|fleet|كمبيوتر|computers?|سيرفرات|servers?|machines?|vps|cloud|remote|ريموت|metasploit|burp(?:\s*suite)?|مثبت|installed)/i,
    tools: (msg) => {
      const cmd = extractFleetCommand(msg);
      if (!cmd) return [{ tool: "fleet_list", args: {} }];
      return [{ tool: "fleet_list", args: {} }, { tool: "fleet_exec", args: { command: cmd } }];
    },
  },
  {
    // A bare "نفّذ `whoami`" with no machine mentioned still means the fleet.
    test: /(?:نفّذ|نفذ|شغّل|شغل|اعمل|run|execute|exec)\s+(?:الأمر|الامر|command|دي|ده|كود|امر|أمر)?\s*`[^`]+`/i,
    tools: (msg) => {
      const cmd = extractFleetCommand(msg);
      return cmd ? [{ tool: "fleet_exec", args: { command: cmd } }] : [];
    },
  },
  {
    // Recall must be checked BEFORE save, otherwise "تفتكر ايه عني" (what do you
    // remember about me?) matches the save verb "افتكر" and stores a memory.
    test: /(?:تفتكر|تتذكر|فاكر|فاتكر|تذكر|\bذكرى|ذاكرت|الذاكرة|\bmemory\b|what do you remember|\brecall\b)/i,
    tools: (msg) => {
      const q = cleanQuery(
        msg
          .replace(/(?:انت\s*)?(?:تفتكر|تتذكر|فاكر|فاتكر)\s*(?:ايه|إيه|ايوه|عن|حاجة|حاجه)?/gi, " ")
          .replace(/(?:ايه|إيه)\s*(?:اللي)?/gi, " ")
          .replace(/\s+/g, " "),
      );
      return [{ tool: "memory_search", args: { query: q || msg } }];
    },
  },
  {
    test: /(?:^|[\s،,])(?:احفظ|سجّل|سجل|remember|حفظ)(?![\p{L}])/iu,
    tools: (msg) => {
      // "احفظ ان ..." → keep the payload, not the command verb.
      const body =
        msg
          .replace(/^\s*(?:من فضلك\s*|please\s*)?(?:احفظ|سجّل|سجل|remember|حفظ|افتكر)\s*/i, "")
          .replace(/^\s*(?:اني|أني|إني|انه|أنه|إنه|ان|أن|إن|that|ه)\s+/i, "")
          .trim() || msg;
      const isPreference = /(?:انا\s*(?:افضل|أفضل|بحب|عايز|محتاج)|دايماً|دائماً|دائما|كل مرة|always|prefer|i want you to)/i.test(msg);
      return [{
        tool: "memory_save",
        args: {
          title: body.slice(0, 70),
          content: body,
          kind: isPreference ? "preference" : "fact",
          importance: isPreference ? 9 : 7,
        },
      }];
    },
  },
  {
    test: /(?:الهدف النشط|حدد هدف|set target|active target)/i,
    tools: (msg) => {
      const host = extractTarget(msg);
      return host ? [{ tool: "set_active_target", args: { target: host } }] : [{ tool: "mission_status", args: {} }];
    },
  },
  {
    test: /(?:المهمة|mission|findings|النتائج)/i,
    tools: () => [{ tool: "mission_status", args: {} }],
  },
  {
    test: /(?:تقدر تعمل ايه|تقدر تعمل إيه|تقدر تساعدني|تقدر تساعد|قدراتك|إمكانياتك|امكانياتك|مهامك|what can you do|your capabilities)/i,
    tools: () => [{ tool: "task_list", args: {} }],
  },
  {
    test: /(?:حالة المنصة|status|صحة|health|إحصائ)/i,
    tools: () => [{ tool: "platform_status", args: {} }],
  },
  {
    test: /(?:كيف أحمي|إصلاح|ترقيع|remediat|fix|حماية)/i,
    tools: (msg) => [{ tool: "knowledge_search", args: { query: cleanQuery(msg) } }],
  },
];

function cleanQuery(msg: string): string {
  return msg
    .replace(/CVE-\d{4}-\d{4,7}/gi, " ")
    .replace(/\bhttps?:\/\/\S+/gi, " ")
    .replace(/\b((?:[a-z0-9-]+\.)+[a-z]{2,24})\b/gi, " ")
    .replace(/(?:من فضلك|لو سمحت|يا نوفا|please|could you|can you)/gi, " ")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 90) || "أمن سيبراني";
}

/**
 * Pull the shell command out of a natural-language request.
 * Handles backticks first ("نفّذ `uname -a` على الأجهزة"), then "نفّذ <cmd> على/في …".
 */
export function extractFleetCommand(message: string): string | null {
  const ticked = message.match(/`([^`]{1,400})`/);
  if (ticked) return ticked[1].trim();
  const after = message.match(
    /(?:نفّذ|نفذ|شغّل|شغل|اعمل|run|execute|exec)\s+(?:الأمر|الامر|command|التالى|التالي)?\s*([^\n]{1,300}?)\s*(?:\s+(?:على|علي|في|فى|داخل|عند|across|on)\b|$)/i,
  );
  const raw = after?.[1]?.trim();
  if (!raw) return null;
  // Reject prose ("uname -a على الأجهزة" is fine, "الاجهزة المتصلة" is not a command).
  if (!/[a-z0-9_.\-]/i.test(raw)) return null;
  // Cut the trailing Arabic prose: "uname -a على الأجهزة" → "uname -a".
  const tokens = raw.split(/\s+/);
  const kept: string[] = [];
  for (const t of tokens) {
    if (/[\u0600-\u06FF]/.test(t)) break;
    if (/^(?:on|across|in)$/i.test(t)) break;
    kept.push(t);
  }
  const stop = kept.join(" ").trim();
  if (!stop || stop.length > 200) return null;
  if (/^(?:الأجهزة|الاجهزة|أجهزة|اجهزة|الأجهزه|fleet|devices?)$/i.test(stop)) return null;
  return stop;
}

const SMALL_TALK = /^(?:أهلا|اهلا|أهلًا|اهلين|أهلين|مرحبا|مرحباً|مرحبًا|السلام|سلام|صباح|مساء|hi|hello|hey|ازيك|إزيك|عامل ايه)/i;

export function heuristicPlan(message: string): { thought: string; steps: PlannedStep[]; directAnswer?: string } {
  const msg = message.trim();
  if (!msg) return { thought: "مفيش طلب واضح.", steps: [] };

  const host = extractTarget(msg);
  if (SMALL_TALK.test(msg) && !host) {
    return {
      thought: "تحية بسيطة — أرد على المستخدم مباشرة من غير استدعاء أدوات أو افتراض هدف.",
      steps: [],
      directAnswer: "أهلاً بيك! أنا NOVA، مساعد المنصة. نكمل من آخر موضوع كنا بنتكلم فيه، ولا عندك طلب جديد؟",
    };
  }
  if (/(?:انت مين|من أنت|مين انت|who are you|شخصيتك)/i.test(msg)) {
    return {
      thought: "سؤال عن هوية NOVA وقدراتها — أجيب بالقدرات المسجلة والقيود الفعلية.",
      steps: [],
      directAnswer: [
        "أنا NOVA، مساعد داخل CyberNova. أقدر أستخدم الأدوات المسجلة في هذه النسخة للبحث العام، بيانات CVE، الاستطلاع المحدود، الذاكرة، المهام، وحالة الأسطول.",
        `المسجل حاليًا: ${AGENT_TOOLS.length} أداة. التسجيل لا يضمن أن كل مزوّد أو جهاز متاح؛ لازم نتحقق من نتيجة الأداة وقت الطلب.`,
        `الأجهزة المتصلة الآن: ${safeFleetSummary()}.`,
        "ما عنديش تحكم مباشر بسطح المكتب أو متصفح المستخدم من هذه المحادثة. أوامر الأجهزة الحقيقية حساسة ومقفولة حتى يتوفر مسار موافقة موثوق.",
      ].join("\n\n"),
    };
  }

  const steps: PlannedStep[] = [];
  for (const rule of INTENT) {
    if (!rule.test.test(msg)) continue;
    const planned = rule.tools(msg);
    if (!planned.length) continue;
    for (const step of planned) {
      if (!AGENT_TOOL_NAMES.includes(step.tool)) continue;
      if (steps.some((s) => s.tool === step.tool && JSON.stringify(s.args) === JSON.stringify(step.args))) continue;
      steps.push(step);
    }
    if (steps.length >= 4) break;
  }

  if (steps.length === 0 && host) {
    steps.push({ tool: "set_active_target", args: { target: host } }, { tool: "recon_target", args: { target: host } });
  }
  if (steps.length === 0) {
    steps.push({ tool: "memory_search", args: { query: msg.slice(0, 80) } }, { tool: "platform_status", args: {} });
  }

  const thought = host
    ? `الطلب فيه هدف واضح (${host}) — هبدأ بالاستطلاع الحقيقي وأبني عليه.`
    : `هجمع السياق من ذاكرتي وحالة المنصة قبل أي استنتاج.`;
  return { thought, steps: steps.slice(0, 5) };
}

/* ── LLM planner ─────────────────────────────────────────────────────────── */

const PLAN_INSTRUCTIONS = `أعد **JSON فقط** (بدون أي شرح خارج الـ JSON) بهذا الشكل:
{"thought": "ملخص موجز للإجراء التالي، من غير سرد التفكير الداخلي", "steps": [{"tool": "اسم_الأداة", "args": {...}}], "answer_if_no_tools": "رد نصي فقط إذا لم تحتج أدوات"}

قواعد:
- استخدم أدوات حقيقية فقط من القائمة. لا تخترع أسماء.
- أقصى عدد خطوات 4.
- لو السؤال عام/تحية/تعريف بشخصيتك → steps فارغة واكتب الرد في answer_if_no_tools.
- لا تذكر هدفاً نشطاً أو جهازاً أو برنامجاً أو نتيجة إلا إذا ظهر في سياق المنصة أو خرج أداة لهذا الدور.
- سؤال حالة الأجهزة يُجاب من fleet_list فقط؛ لا تستدعِ fleet_profile إذا لم توجد أجهزة متصلة.
- لا تقترح فحص هدف حي تلقائياً؛ افحص سجل البرنامج ونطاقه وسياساته أولاً، واسأل عن توضيح عند الحاجة.
- لو فيه CVE أو معلومة حديثة، استخدم أداة البحث المناسبة ولا تجاوب من ذاكرتك.`;

async function llmPlan(
  message: string,
  history: Array<{ role: "user" | "assistant"; content: string }>,
): Promise<{ thought: string; steps: PlannedStep[]; directAnswer?: string; provider: string; model: string } | null> {
  const messages = [
    { role: "system" as const, content: `${NOVA_SYSTEM_PROMPT_SHORT}\n\n# أدواتك\n${toolCatalogueForPrompt()}\n\n${buildContextBlock(message)}\n\n${PLAN_INSTRUCTIONS}` },
    ...history.slice(-4).map((h) => ({ role: h.role, content: h.content.slice(0, 1200) })),
    { role: "user" as const, content: message },
  ];
  const result = await llmComplete(messages, { temperature: 0.3, maxTokens: 700 });
  if (!result) return null;
  const parsed = extractJson<{ thought?: string; steps?: Array<{ tool?: string; args?: Record<string, unknown> }>; answer_if_no_tools?: string }>(result.text);
  if (!parsed) return null;
  const steps = (parsed.steps ?? [])
    .filter((s) => s?.tool && AGENT_TOOL_NAMES.includes(String(s.tool)))
    .slice(0, 4)
    .map((s) => ({ tool: String(s.tool), args: (s.args ?? {}) as Record<string, unknown> }));
  return {
    thought: String(parsed.thought ?? "تمام، هبدأ بالخطة."),
    steps,
    directAnswer: parsed.answer_if_no_tools ? String(parsed.answer_if_no_tools) : undefined,
    provider: result.provider,
    model: result.model,
  };
}

/* ── explanation ─────────────────────────────────────────────────────────── */

function preview(data: unknown): string {
  try {
    const s = JSON.stringify(data);
    return s.length > 700 ? `${s.slice(0, 700)}…` : s;
  } catch {
    return String(data).slice(0, 400);
  }
}

function heuristicAnswer(message: string, results: Array<{ name: string; ok: boolean; summary: string; data: unknown }>): string {
  if (results.length === 0) {
    if (SMALL_TALK.test(message.trim())) {
      return "أهلاً بيك! أنا NOVA، مساعد المنصة. نكمل من آخر موضوع كنا بنتكلم فيه، ولا عندك طلب جديد؟";
    }
    return `أنا **نوفا**، مساعد داخل CyberNova. أستخدم الأدوات المسجلة في هذه النسخة وأعرض نتائجها الفعلية؛ عدد الأدوات المسجلة الآن ${AGENT_TOOLS.length}، وده لا يضمن توافر كل مزوّد أو جهاز.\n\nأقدر أساعد في البحث العام، بيانات CVE، الاستطلاع المحدود، الذاكرة، المهام، وحالة الأسطول. التحكم بمتصفحك أو سطح المكتب غير متاح من هذا الشات، وتنفيذ الأوامر على جهاز حقيقي غير متاح قبل وجود موافقة موثقة.\n\n**الخطوة التالية المقترحة:** قلّي المطلوب تحديداً؛ لو عن جهاز أو قدرة، أتحقق من حالتها الحالية قبل ما أقول إنها شغالة.`;
  }

  const lines: string[] = [];
  const failed = results.filter((r) => !r.ok);
  const okCount = results.length - failed.length;

  const web = results.find((r) => r.name === "web_search");
  if (web) {
    const data = web.data as { query?: string; results?: Array<{ title?: string; url?: string; snippet?: string }> } | null;
    const hits = data?.results ?? [];
    const fleetResult = results.find((r) => r.name === "fleet_list");
    return [
      `بحثت على الويب عن: **${data?.query ?? "الاستضافة المجانية"}**.`,
      web.ok && hits.length
        ? hits.map((hit) => `- [${hit.title ?? hit.url ?? "نتيجة"}](${hit.url ?? "#"})${hit.snippet ? ` — ${hit.snippet}` : ""}`).join("\n")
        : `البحث لم يرجع نتائج قابلة للاستخدام: ${web.summary}`,
      fleetResult ? `\n**حالة الأجهزة المرتبطة:** ${fleetResult.summary}` : "",
      "\nدي معلومات بحث وليست جهازًا تم إنشاؤه أو ربطه. فتح حساب أو إنشاء موارد سحابية يحتاج موافقتك وإعداداتك لدى المزود.",
    ].filter(Boolean).join("\n");
  }

  const fleet = results.find((r) => r.name === "fleet_list");
  if (fleet) {
    const data = fleet.data as { count?: number; agents?: Array<{ hostname?: string; platform?: string; capabilities?: string[] }> } | null;
    if (!fleet.ok || !data?.count) {
      return [
        "راجعت حالة الأسطول الحالية: **مافيش جهاز متصل بنوفا دلوقتي**، فمش هقدر أؤكد وجود كمبيوتر أو أدوات Kali جاهزة للتشغيل.",
        "نوفا ما بتستأجرش أو تشغّل أجهزة مجانية لطرف ثالث من تلقاء نفسها. اربط جهازاً تملكه أو عندك إذن بإدارته باستخدام وكيل NOVA؛ بعدها أقدر أعرض بيانات الاتصال والقدرات التي يبلّغ عنها الوكيل. وجود Metasploit أو Burp Suite لازم يتأكد من الجهاز نفسه، مش من مجرد ظهوره في دليل الأدوات.",
        "",
        "**الخطوة التالية المقترحة:** شغّل الوكيل على جهاز أو بيئة اختبار مصرّح بها، ثم اطلب مني إعادة فحص حالة الاتصال.",
      ].join("\n");
    }

    const agents = data.agents ?? [];
    const machineList = agents
      .map((agent) => {
        const capabilities = agent.capabilities?.length ? agent.capabilities.join(", ") : "لم يبلّغ عن قدرات";
        return `- **${agent.hostname ?? "جهاز"}** (${agent.platform ?? "النظام غير معروف"}): ${capabilities}`;
      })
      .join("\n");
    return [
      `لقيت **${data.count} جهاز متصل فعلياً** حسب لقطة الأسطول الحالية:`,
      machineList,
      "",
      "دي بيانات الوكلاء المتصلين فقط؛ مش دليل على تثبيت أداة بعينها أو على وجود إذن لاستخدام الجهاز. أي أمر على جهاز حقيقي محتاج موافقتك الصريحة.",
      "",
      "**الخطوة التالية المقترحة:** قلّي اسم الجهاز والأداة اللي عايز تتحقق منها، وأراجع القدرات المبلّغ عنها قبل أي إجراء.",
    ].join("\n");
  }

  const capabilityList = results.find((r) => r.name === "task_list");
  if (capabilityList && capabilityList.ok && Array.isArray(capabilityList.data)) {
    const items = capabilityList.data as Array<{ title?: string; category?: string; risk?: string }>;
    const summary = items
      .map((item) => `- ${item.title ?? "قدرة"} (${item.category ?? "عام"}${item.risk && item.risk !== "safe" ? ` · ${item.risk}` : ""})`)
      .join("\n");
    return [
      `دي القدرات المسجّلة والمتاحة في نسخة المنصة الحالية (**${items.length}**):`,
      summary || "- أداة القدرات رجعت قائمة فارغة.",
      "",
      "القائمة بتوصف وظائف المنصة، مش ضماناً إن جهازاً خارجياً أو أداة Kali مثبتة ومتاحة الآن؛ حالة الأجهزة لازم تتفحص بشكل منفصل.",
      "",
      "**الخطوة التالية المقترحة:** اختار قدرة أو اسألني عن حالة الأجهزة المتصلة عشان أتحقق منها مباشرة.",
    ].join("\n");
  }

  lines.push(`تمام، نفّذت **${results.length}** أداة (${okCount} نجحت${failed.length ? ` · ${failed.length} فشلت` : ""}). دي القراءة:`);
  lines.push("");

  for (const r of results) {
    lines.push(`### ${r.ok ? "✅" : "⚠️"} ${r.name}`);
    lines.push(r.summary);
    lines.push("");
  }

  const recon = results.find((r) => r.name === "recon_target" && r.ok);
  if (recon) {
    const data = recon.data as { headers?: { missing?: string[]; score?: string }; tls?: { validTo?: string; authorizationError?: string | null } };
    const missing = data?.headers?.missing ?? [];
    lines.push("## القراءة الأمنية");
    if (missing.length) {
      lines.push(`- **ترويسات ناقصة (${missing.length}):** ${missing.join(", ")} — أول ما يحتاج معالجة.`);
    } else {
      lines.push("- الترويسات الأساسية موجودة — مش معناها كمال، بس مش ناقصة الحاجات الحرجة.");
    }
    lines.push(
      data?.tls?.authorizationError
        ? `- **الشهادة فيها مشكلة:** ${data.tls.authorizationError}`
        : `- الشهادة سارية حتى **${data?.tls?.validTo ?? "غير معروف"}**.`,
    );
    lines.push("- الاستطلاع ده سطحي ومقصود: بيوريك الشكل الخارجي بدون أي أذى للهدف.");
    lines.push("");
  }

  if (failed.length) {
    lines.push("## اللي فشل وليه");
    for (const f of failed) lines.push(`- **${f.name}:** ${f.summary}`);
    lines.push("");
  }

  lines.push("## الخطوة التالية المقترحة");
  if (recon) {
    lines.push("نكمّل بفحص المنافذ المحدود + تعداد النطاقات الفرعية، وبعدها نسجّل النتائج في المهمة ونولّد تقرير قانوني جاهز للإرسال.");
  } else if (results.some((r) => r.name === "cve_lookup" || r.name === "vuln_search")) {
    lines.push("نشوف لو الثغرة لسه مؤثرة على نسختك الفعلية، ونجهّز كود الترقيع (Remediation) قبل أي إبلاغ.");
  } else {
    lines.push("ابعتلي نطاقاً لاستطلاعه فعلياً، أو CVE لنبحث عنها في NVD.");
  }
  return lines.join("\n");
}

/* ── main loop ───────────────────────────────────────────────────────────── */

let memoryBooted = false;

/** Approvals that were asked for and never answered (surfaced by /nova-core/pending). */
export const pendingApprovals: Array<{ sessionId: string; tool: string; args: Record<string, unknown>; at: number }> = [];

export async function runAgent(opts: AgentRunOptions): Promise<AgentRunResult> {
  if (!memoryBooted) {
    memoryBooted = true;
    try {
      initMemory();
    } catch {
      /* store failures must never block a reply */
    }
  }
  const started = Date.now();
  const sessionId = opts.sessionId || `nova-${Date.now()}`;
  const history = opts.history ?? [];
  const message = (opts.message ?? "").trim();

  if (!message) {
    opts.emit({ type: "error", message: "مفيش رسالة — اكتب طلبك." });
    return { mode: "heuristic", provider: "none", toolsUsed: [], reply: "", ms: 0 };
  }

  let plan: { thought: string; steps: PlannedStep[]; directAnswer?: string } | null = null;
  let mode: "llm" | "heuristic" = "heuristic";
  let provider = "nova-builtin";
  let model = "nova-heuristic";
  const deterministicPlan = heuristicPlan(message);

  if (deterministicPlan.directAnswer) {
    plan = deterministicPlan;
  } else if (!opts.forceHeuristic) {
    const llm = await llmPlan(message, history);
    if (llm && (llm.steps.length > 0 || llm.directAnswer)) {
      plan = llm;
      mode = "llm";
      provider = llm.provider;
      model = llm.model;
    }
  }
  if (!plan) {
    plan = deterministicPlan;
    mode = "heuristic";
  }

  // Avoid a redundant failing profile call after the same plan has already
  // established that no agents are connected.
  if (
    plan.steps.some((step) => step.tool === "fleet_list") &&
    plan.steps.some((step) => step.tool === "fleet_profile") &&
    getConnectedAgentList().length === 0
  ) {
    plan.steps = plan.steps.filter((step) => step.tool !== "fleet_profile");
  }

  opts.emit({
    type: "ready",
    sessionId,
    mode,
    provider,
    model,
    tools: AGENT_TOOLS.length,
  });
  opts.emit({ type: "thought", text: plan.thought });

  // Direct answer without tools (identity / chit-chat / general question)
  if (plan.steps.length === 0) {
    let reply = plan.directAnswer?.trim() || "";
    if (!reply) {
      const llm = await llmComplete(
        [
          { role: "system", content: `${NOVA_SYSTEM_PROMPT}\n\n${buildContextBlock(message)}` },
          ...history.slice(-4).map((h) => ({ role: h.role, content: h.content.slice(0, 1200) })),
          { role: "user", content: message },
        ],
        { temperature: 0.7 },
      );
      reply = llm?.text?.trim() || heuristicAnswer(message, []);
      if (llm) provider = llm.provider;
    }
    for (const chunk of splitChunks(reply)) {
      opts.emit({ type: "delta", text: chunk });
      await sleep(8);
    }
    opts.emit({ type: "done", sessionId, mode, toolCount: 0, ms: Date.now() - started, provider });
    return { mode, provider, toolsUsed: [], reply, ms: Date.now() - started };
  }

  // Execute the plan
  opts.emit({ type: "plan", steps: plan.steps });
  const results: Array<{ name: string; ok: boolean; summary: string; data: unknown }> = [];
  const maxSteps = Math.min(opts.maxSteps ?? 5, 6);

  for (const [idx, step] of plan.steps.slice(0, maxSteps).entries()) {
    const spec = AGENT_TOOLS.find((t) => t.name === step.tool);
    const id = `${idx + 1}-${step.tool}`;
    opts.emit({
      type: "tool_call",
      id,
      name: step.tool,
      title: spec?.title ?? step.tool,
      args: step.args,
      risk: spec?.risk ?? "safe",
    });

    // ── human-in-the-loop gate ────────────────────────────────────────────
    // Sensitive tools stop here and ask. The client answers by re-sending the
    // same message with `approve: [tool]`; only then does anything execute.
    const risk = String(spec?.risk ?? "safe");
    const needsApproval = risk === "sensitive" || (risk === "active" && opts.requireApprovalForActive);
    if (needsApproval && !(opts.approved ?? []).includes(step.tool)) {
      const reason = risk === "active"
        ? `الأداة «${spec?.title ?? step.tool}» تتفاعل نشطًا مع هدف شبكي؛ لن يتم تنفيذها قبل موافقة صريحة.`
        : `الأداة «${spec?.title ?? step.tool}» حساسة — ممكن تنفّذ أوامر على جهاز حقيقي. محتاج موافقتك قبل التنفيذ.`;
      opts.emit({ type: "confirm_required", id, name: step.tool, title: spec?.title ?? step.tool, args: step.args, risk, reason });
      pendingApprovals.push({ sessionId, tool: step.tool, args: step.args, at: Date.now() });
      results.push({ name: step.tool, ok: false, summary: "⏸️ متوقفة لحد ما توافق على التنفيذ", data: null });
      continue;
    }

    broadcastLiveEvent({
      type: "tool_start",
      data: { tool: step.tool, args: step.args, agent: "nova", ts: Date.now() },
      ts: new Date().toISOString(),
    });

    let result: ToolRunResult;
    try {
      result = await runAgentTool(step.tool, step.args);
    } catch (err) {
      result = { ok: false, summary: `خطأ غير متوقع: ${(err as Error).message}`, data: null, ms: 0 };
    }

    results.push({ name: step.tool, ok: result.ok, summary: result.summary, data: result.data });
    opts.emit({
      type: "tool_result",
      id,
      name: step.tool,
      ok: result.ok,
      summary: result.summary,
      ms: result.ms,
      dataPreview: preview(result.data),
    });
    broadcastLiveEvent({
      type: "tool_result",
      data: { tool: step.tool, ok: result.ok, summary: result.summary, ms: result.ms, ts: Date.now() },
      ts: new Date().toISOString(),
    });
    broadcastEvent({ type: "agent_tool_result", agent: "nova", tool: step.tool, ok: result.ok, ts: Date.now() });

    if (step.tool === "recon_target" || step.tool === "port_scan" || step.tool === "subdomain_enum") {
      recordMissionCommand(
        `nova:${step.tool} ${JSON.stringify(step.args)}`,
        result.summary,
      );
    }
  }

  // Explain the results
  let reply = "";
  if (results.some((r) => r.name === "fleet_list" || r.name === "web_search")) {
    // Machine inventory and search results are factual state; render them from
    // the returned data instead of letting a model embellish or invent status.
    reply = heuristicAnswer(message, results);
  } else if (mode === "llm") {
    const llm = await llmComplete(
      [
        {
          role: "system",
          content: `${NOVA_SYSTEM_PROMPT}\n\n# مخرجات أدواتك الحقيقية الآن (استخدمها كما هي، لا تخترع غيرها)\n${results
            .map((r) => `## ${r.name} (${r.ok ? "نجحت" : "فشلت"}): ${r.summary}\n${preview(r.data).slice(0, 1500)}`)
            .join("\n\n")}\n\n# سياق\n${buildContextBlock(message)}`,
        },
        { role: "user", content: `${message}\n\nفسّر النتائج باختصار، اذكر المهم والخطورة، واختم بخطوة تالية واحدة.` },
      ],
      { temperature: 0.5, maxTokens: 1200 },
    );
    reply = llm?.text?.trim() ?? "";
    if (llm) provider = llm.provider;
  }
  if (!reply) reply = heuristicAnswer(message, results);

  for (const chunk of splitChunks(reply)) {
    opts.emit({ type: "delta", text: chunk });
    await sleep(6);
  }

  // ── Long-term memory: this is what makes NOVA remember across restarts ──
  try {
    const scope = cleanScope(extractTarget(message) ?? getMissionsState()[0]?.target);
    const summary = results.map((r) => `${r.name} → ${r.summary}`).join(" | ").slice(0, 1800);

    // 1) A session record (searchable transcript digest).
    const sessionRec = remember({
      kind: "session",
      title: `جلسة نوفا: ${message.slice(0, 60)}`,
      content: `سؤال: ${message}\nالأدوات: ${results.map((r) => r.name).join(", ") || "بدون"}\nالنتائج: ${summary}\nالرد: ${reply.slice(0, 700)}`,
      scope,
      tags: ["session", ...results.map((r) => r.name)],
      importance: 5,
      source: "agent",
    });

    // 2) A lesson whenever a tool actually produced something durable.
    const facts = results.filter((r) => r.ok && r.name !== "platform_status");
    if (facts.length) {
      remember({
        kind: "lesson",
        title: `نتيجة ${facts[0].name} على ${scope}`,
        content: facts.map((r) => `${r.name}: ${r.summary}`).join("\n").slice(0, 1500),
        scope,
        tags: ["auto", ...facts.map((r) => r.name)],
        importance: 6,
        source: "agent-auto",
      });
    }

    // Mirror into the platform feed so /memory keeps working unchanged.
    try {
      saveMemory("session", sessionRec.title, sessionRec.content.slice(0, 1200), "nova,session,longterm", 6, false);
    } catch {
      /* best-effort */
    }
    opts.emit({ type: "memory", id: sessionRec.id, title: sessionRec.title });
  } catch {
    /* memory is best-effort — never fail a run because of it */
  }

  const out: AgentRunResult = {
    mode,
    provider,
    toolsUsed: results.map((r) => r.name),
    reply,
    ms: Date.now() - started,
  };
  opts.emit({ type: "done", sessionId, mode, toolCount: results.length, ms: out.ms, provider });
  return out;
}

/* ── utils ───────────────────────────────────────────────────────────────── */

function splitChunks(text: string, size = 48): string[] {
  if (!text) return [];
  return text.match(new RegExp(`[\\s\\S]{1,${size}}`, "g")) ?? [text];
}

/** A stable scope key: bare hostname when we can find one, otherwise "global". */
function cleanScope(raw: string | undefined | null): string {
  if (!raw) return "global";
  let v = String(raw).trim().toLowerCase();
  try {
    if (/^https?:\/\//.test(v)) v = new URL(v).hostname;
  } catch {
    /* keep as-is */
  }
  const host = v.match(/^([a-z0-9][a-z0-9.-]*\.[a-z]{2,24})/);
  if (host) return host[1];
  return v.length > 0 && v.length <= 60 ? v : "global";
}

function sleep(ms: number): Promise<void> {
  return new Promise((r) => setTimeout(r, ms));
}
