/**
 * NOVA — LLM Bridge
 * ─────────────────
 * Zero-cost-first model access. Tries, in order:
 *   1. Ollama on your machine (free, offline) — OLLAMA_BASE_URL / settings
 *   2. Free-tier cloud APIs if keys exist in env
 *      (Groq, OpenRouter, Google Gemini via OpenAI-compatible endpoint, Mistral)
 *   3. Nothing available → caller falls back to the deterministic planner, so the
 *      agent still works end-to-end (tools are executed for real either way).
 */

import { getOllamaBaseUrl, getOllamaModel } from "../ollama-settings";
import { resolveOllamaBase, preferredOllamaModel } from "./ollama-manager";
import { logger } from "../logger";

export type LlmRole = "system" | "user" | "assistant";

export interface LlmMessage {
  role: LlmRole;
  content: string;
}

export interface LlmProviderInfo {
  id: string;
  label: string;
  model: string;
  kind: "ollama" | "openai-compatible";
  baseUrl: string;
  apiKey?: string;
  free: boolean;
}

export interface LlmResult {
  text: string;
  provider: string;
  model: string;
  ms: number;
}

const TIMEOUT_MS = 20_000;
const SETTINGS_TIMEOUT_MS = 1_500;

/**
 * The settings store lives in Postgres. In standalone mode (no DATABASE_URL) the
 * read can stall, which would freeze the whole agent before the first token.
 * Always resolve provider config against a hard deadline.
 */
function withDeadline<T>(promise: Promise<T>, ms: number, fallback: T): Promise<T> {
  return new Promise<T>((resolve) => {
    const timer = setTimeout(() => resolve(fallback), ms);
    promise
      .then((v) => resolve(v))
      .catch(() => resolve(fallback))
      .finally(() => clearTimeout(timer));
  });
}

/** Ordered list of providers that are actually configured right now. */
export async function listConfiguredProviders(): Promise<LlmProviderInfo[]> {
  const providers: LlmProviderInfo[] = [];

  // 1. Local Ollama — free, private, and auto-discovered (works inside Docker too)
  try {
    const envBase = (process.env.OLLAMA_BASE_URL || "http://127.0.0.1:11434").replace(/\/$/, "");
    const discovered = await resolveOllamaBase();
    const baseUrl = discovered ?? (await withDeadline(getOllamaBaseUrl(), SETTINGS_TIMEOUT_MS, envBase));
    const model = discovered
      ? await preferredOllamaModel()
      : await withDeadline(getOllamaModel(), SETTINGS_TIMEOUT_MS, process.env.OLLAMA_MODEL || "qwen2.5:3b");
    providers.push({
      id: "ollama",
      label: "Ollama (محلي مجاني)",
      model,
      kind: "ollama",
      baseUrl,
      free: true,
    });
  } catch {
    providers.push({
      id: "ollama",
      label: "Ollama (محلي مجاني)",
      model: process.env.OLLAMA_MODEL || "qwen2.5:3b",
      kind: "ollama",
      baseUrl: (process.env.OLLAMA_BASE_URL || "http://127.0.0.1:11434").replace(/\/$/, ""),
      free: true,
    });
  }

  // 2. Free-tier cloud providers (only when the user supplies a key)
  const envProviders: Array<{ id: string; label: string; baseUrl: string; model: string; keys: string[] }> = [
    {
      id: "groq",
      label: "Groq (free tier)",
      baseUrl: "https://api.groq.com/openai/v1",
      // Measured 2026-11-06 against a real key: `openai/gpt-oss-120b` answers 200
      // with an EMPTY content string, while `qwen/qwen3.8-27b` returns real
      // Arabic text. An empty 200 is worse than a 404 — it looks like success and
      // the user gets a blank reply — so the default is the model that speaks.
      model: process.env.GROQ_MODEL || "qwen/qwen3.8-27b",
      keys: ["GROQ_API_KEY"],
    },
    {
      id: "openrouter",
      label: "OpenRouter (free models)",
      baseUrl: "https://openrouter.ai/api/v1",
      // Measured 2026-11-06: `openai/gpt-oss-120b:free` is no longer a free slug
      // (404 "unavailable for free"). `nvidia/nemotron-3-ultra-550b-a55b:free`
      // answered 200 with real content on the same key.
      model: process.env.OPENROUTER_MODEL || "nvidia/nemotron-3-ultra-550b-a55b:free",
      keys: ["OPENROUTER_API_KEY"],
    },
    {
      id: "gemini",
      label: "Google Gemini (free tier)",
      baseUrl: "https://generativelanguage.googleapis.com/v1beta/openai",
      // Measured 2026-11-06: `gemini-2.0-flash` is retired (404) and
      // `gemini-2.5-flash` answered 503 "high demand" on the same key, while
      // `gemini-3.5-flash` answered 200. Default to the one that is serving.
      model: process.env.GEMINI_MODEL || "gemini-3.5-flash",
      keys: ["GEMINI_API_KEY", "GOOGLE_API_KEY"],
    },
    {
      id: "mistral",
      label: "Mistral (free tier)",
      baseUrl: "https://api.mistral.ai/v1",
      model: process.env.MISTRAL_MODEL || "mistral-small-latest",
      keys: ["MISTRAL_API_KEY"],
    },
    {
      id: "together",
      label: "Together AI (free models)",
      baseUrl: "https://api.together.xyz/v1",
      model: process.env.TOGETHER_MODEL || "meta-llama/Llama-3.3-70B-Instruct-Turbo-Free",
      keys: ["TOGETHER_API_KEY"],
    },
    {
      // Free tier, very fast inference; OpenAI-compatible so no extra code path.
      id: "cerebras",
      label: "Cerebras (free tier)",
      baseUrl: "https://api.cerebras.ai/v1",
      model: process.env.CEREBRAS_MODEL || "llama-3.3-70b",
      keys: ["CEREBRAS_API_KEY"],
    },
    {
      // GitHub Models: free with any GitHub token, rate-limited per day.
      // The token is read from the environment only — never logged, never stored.
      id: "github-models",
      label: "GitHub Models (free with token)",
      baseUrl: "https://models.github.ai/inference",
      model: process.env.GITHUB_MODELS_MODEL || "openai/gpt-4o-mini",
      keys: ["GITHUB_MODELS_TOKEN"],
    },
  ];

  // OpenAI stays last: it is the only paid option, so it is a true last resort.
  if (process.env.OPENAI_API_KEY && process.env.OPENAI_API_KEY.trim().length > 8) {
    envProviders.push({
      id: "openai",
      label: "OpenAI (مدفوع — آخر خيار)",
      baseUrl: "https://api.openai.com/v1",
      model: process.env.OPENAI_MODEL || "gpt-4o-mini",
      keys: ["OPENAI_API_KEY"],
    });
  }

  /*
   * 3. Keyless providers.
   *
   * A provider that needs no account at all is worth more than a free tier
   * behind a signup: it keeps the council alive on a fresh install where the
   * only .env is the one we shipped. Pollinations serves GPT-OSS-20B on its
   * anonymous tier through an OpenAI-compatible endpoint — no key, no card.
   *
   * Verified before wiring (2026-11-01): POST /openai with model "openai-fast"
   * → {"choices":[{"message":{"content":"ready"}}],"model":"gpt-oss-20b"}.
   * Disable with NOVA_KEYLESS_LLM=0 if it ever misbehaves.
   */
  /**
   * Keyless seats are ONE PER MODEL, not one per provider, because the council
   * needs ≥2 independent voices and a single endpoint with a single model gives
   * it one. text.pollinations.ai answers different model ids on the same
   * OpenAI-compatible route with no account, so `openai-fast` + `mistral` +
   * `llama` = three real voters for $0. Override the list with
   * NOVA_KEYLESS_SEATS="openai-fast,mistral" (comma separated) if a model is
   * retired — a dead seat is skipped at call time, never fatal.
   */
  const keylessModels = String(process.env.NOVA_KEYLESS_SEATS ?? "openai-fast,mistral,llama")
    .split(",")
    .map((v) => v.trim())
    .filter(Boolean)
    .slice(0, 6);
  const keyless: Array<{ id: string; label: string; baseUrl: string; model: string }> = keylessModels.map(
    (model) => ({
      id: `pollinations:${model}`,
      label: `Pollinations · ${model} (بدون مفتاح)`,
      baseUrl: String(process.env.POLLINATIONS_BASE_URL || "https://text.pollinations.ai/openai").replace(/\/$/, ""),
      model,
    }),
  );

  /**
   * More keyless seats, on other providers — because one provider is one point
   * of failure. Both are OpenAI-compatible with an anonymous tier, verified
   * against their docs on 2026-11-05:
   *
   *   • LLM7  — https://api.llm7.io/v1      · `gpt-oss:20b` answers with no
   *              Authorization header at all (~30 RPM anonymous).
   *   • OVH   — https://oai.endpoints.kepler.ai.cloud.ovh.net/v1 · OVHcloud's
   *              own docs show the keyless examples at ~2 RPM per model.
   *
   * They cost nothing and need no account, which is the only kind of capacity
   * this project is allowed to depend on. `NOVA_EXTRA_KEYLESS=0` removes them
   * if a host ever blocks them; a seat that fails is skipped at call time, so a
   * dead route can never take the brain down with it.
   */
  const extraKeyless: Array<{ id: string; label: string; baseUrl: string; model: string }> = [
    {
      id: "llm7",
      label: "LLM7 · gpt-oss:20b (بدون مفتاح)",
      baseUrl: String(process.env.LLM7_BASE_URL || "https://api.llm7.io/v1").replace(/\/$/, ""),
      model: String(process.env.LLM7_MODEL || "gpt-oss:20b"),
    },
    {
      id: "ovh-ai",
      label: "OVH AI Endpoints · Qwen (بدون مفتاح)",
      baseUrl: String(process.env.OVH_AI_BASE_URL || "https://oai.endpoints.kepler.ai.cloud.ovh.net/v1").replace(/\/$/, ""),
      model: String(process.env.OVH_AI_MODEL || "Qwen3.6-27B"),
    },
  ];

  if (String(process.env.NOVA_KEYLESS_LLM ?? "1") !== "0" && String(process.env.NOVA_EXTRA_KEYLESS ?? "1") !== "0") {
    for (const p of extraKeyless) {
      providers.push({
        id: p.id,
        label: p.label,
        model: p.model,
        kind: "openai-compatible",
        baseUrl: p.baseUrl,
        // Empty string is meaningful here: no Authorization header is sent.
        apiKey: "",
        free: true,
      });
    }
  }

  if (String(process.env.NOVA_KEYLESS_LLM ?? "1") !== "0") {
    // POLLINATIONS_MODEL is honoured only when a single seat is configured: with
    // several seats a global override would put the same model on every seat and
    // the council would be one voice arguing with itself.
    const soloSeat = keyless.length === 1 ? String(process.env.POLLINATIONS_MODEL ?? "").trim() : "";
    for (const p of keyless) {
      const upper = p.id.split(":")[0].toUpperCase().replace(/-/g, "_");
      providers.push({
        id: p.id,
        label: p.label,
        model: soloSeat || p.model,
        kind: "openai-compatible",
        // The endpoint IS the chat route (there is no /v1 base), so mark it and
        // let the caller append nothing.
        baseUrl: (process.env[`${upper}_BASE_URL`] || p.baseUrl).replace(/\/$/, ""),
        apiKey: "",
        free: true,
      });
    }
  }

  for (const p of envProviders) {
    const key = p.keys.map((k) => process.env[k]).find((v) => v && v.trim().length > 8);
    if (!key) continue;
    // Any OpenAI-compatible endpoint can be substituted at runtime, e.g.
    // GROQ_BASE_URL=http://my-proxy/v1 — useful for a self-hosted gateway, a
    // mirror, or pointing a slot at another machine in the fleet.
    const override = (process.env[`${p.id.toUpperCase().replace(/-/g, "_")}_BASE_URL`] || "").trim();
    providers.push({
      id: p.id,
      label: p.label,
      model: process.env[`${p.id.toUpperCase().replace(/-/g, "_")}_MODEL`] || p.model,
      kind: "openai-compatible",
      baseUrl: override ? override.replace(/\/$/, "") : p.baseUrl,
      apiKey: key.trim(),
      free: true,
    });
  }

  return providers;
}

/**
 * ── Model auto-healing ────────────────────────────────────────────────────────
 * Providers retire model ids without warning: Groq decommissioned
 * llama-3.3-70b-versatile on 2026-08-16, Google retired gemini-2.0-flash, and
 * OpenRouter rotates which slugs are free. A hardcoded id therefore rots into a
 * 404 that looks like a broken key.
 *
 * When a model is rejected we ask the provider what it *does* serve
 * (`GET /models`, which every OpenAI-compatible API exposes), pick the best
 * chat model from a preference list, retry once, and remember the choice.
 */

const MODEL_CACHE = new Map<string, string>();

/** Preferred ids per provider, best first. Substring match against /models. */
const MODEL_PREFERENCE: Record<string, string[]> = {
  // Ordered by what actually answered on 2026-11-06, not by what the docs say.
  groq: ["qwen3.8-27b", "qwen3", "gpt-oss-120b", "gpt-oss-20b", "llama-3.3-70b", "llama-3.1-8b"],
  gemini: ["gemini-3.5-flash", "gemini-3.6-flash", "gemini-2.5-flash", "gemini-flash-latest", "gemini-2.5-pro"],
  openrouter: [
    "nemotron-3-ultra-550b-a55b:free",
    "nemotron-3.5-lightning:free",
    "nemotron-3-nano-omni-30b-a3b-reasoning:free",
    "gemma-4-31b-it:free",
    "gemma-4-26b-a4b-it:free",
    "dots-3-note-preview:free",
    "openrouter/free",
  ],
  openai: ["gpt-5-mini", "gpt-4.1-mini", "gpt-4o-mini"],
  cerebras: ["llama-3.3-70b", "gpt-oss-120b", "qwen-3"],
  mistral: ["mistral-small", "open-mistral"],
  together: ["Llama-3.3-70B", "gpt-oss-120b"],
  "github-models": ["gpt-4o-mini", "gpt-4.1-mini", "Phi-4"],
  llm7: ["gpt-oss:20b", "codestral-latest", "mistral-nemo", "minimax", "deepseek"],
  "ovh-ai": ["Qwen3.6-27B", "Meta-Llama-3_3-70B-Instruct", "Mistral-Small", "mistral", "Qwen"],
};

const NOT_CHAT = /embed|whisper|tts|audio|image|dall|moderation|guard|rerank|vision-ocr|realtime|search|transcribe|clip|lyria/i;

/**
 * Some OpenAI-compatible endpoints already *are* the chat route
 * (text.pollinations.ai/openai) and take no Authorization header at all.
 * Centralising that here keeps the two call sites honest.
 */
function chatUrl(provider: LlmProviderInfo): string {
  const base = provider.baseUrl.replace(/\/$/, "");
  return /\/chat\/completions$/.test(base) ? base : `${base}/chat/completions`;
}

function modelsUrl(provider: LlmProviderInfo): string {
  const base = provider.baseUrl.replace(/\/$/, "");
  if (/\/chat\/completions$/.test(base)) return base.replace(/\/chat\/completions$/, "/models");
  return `${base}/models`;
}

function authHeaders(provider: LlmProviderInfo): Record<string, string> {
  return provider.apiKey ? { Authorization: `Bearer ${provider.apiKey}` } : {};
}

function isModelRejection(message: string): boolean {
  return /model|404|not found|does not exist|no longer available|unavailable for free|decommission|deprecat/i.test(message) &&
    !/401|403|invalid api key|unauthor/i.test(message);
}

/** Ask the provider which models this key may call. Returns [] when unsupported. */
async function listProviderModels(provider: LlmProviderInfo): Promise<string[]> {
  try {
    const res = await fetch(modelsUrl(provider), {
      headers: authHeaders(provider),
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return [];
    const data = (await res.json()) as { data?: Array<{ id?: string }>; models?: Array<{ name?: string }> };
    const ids = (data.data ?? []).map((m) => m.id ?? "").filter(Boolean);
    if (ids.length) return ids;
    // Google's native shape: models/gemini-2.5-flash
    return (data.models ?? []).map((m) => (m.name ?? "").replace(/^models\//, "")).filter(Boolean);
  } catch {
    return [];
  }
}

/** Best chat model this provider actually serves, or null. */
async function discoverModel(provider: LlmProviderInfo): Promise<string | null> {
  const available = (await listProviderModels(provider)).filter((id) => !NOT_CHAT.test(id));
  if (available.length === 0) return null;
  const pref = MODEL_PREFERENCE[provider.id] ?? [];
  for (const wanted of pref) {
    const hit = available.find((id) => id.toLowerCase().includes(wanted.toLowerCase()));
    if (hit) return hit;
  }
  return available[0] ?? null;
}

/**
 * Keys that the provider itself rejected (401/403). Retrying them on every
 * message wastes a round-trip and, worse, makes the panel look like it is
 * "trying" a provider that can never answer. Remembered for the process.
 */
const AUTH_REJECTED = new Map<string, string>();

export function providerAuthError(providerId: string): string | null {
  return AUTH_REJECTED.get(providerId) ?? null;
}

function isAuthRejection(message: string): boolean {
  return /\b401\b|\b403\b|incorrect api key|invalid api key|invalid_api_key|unauthor|permission/i.test(message);
}

function isRateLimited(message: string): boolean {
  return /\b429\b|rate.?limit|too many requests|quota|exceeded/i.test(message);
}

/** The model to use: env override → learned choice → configured → discovered. */
export async function resolveModel(provider: LlmProviderInfo): Promise<string> {
  const learned = MODEL_CACHE.get(provider.id);
  if (learned) return learned;
  MODEL_CACHE.set(provider.id, provider.model);
  return provider.model;
}

/**
 * ── Transient-failure retry ──────────────────────────────────────────────────
 * Measured 2026-11-06 on the live slot: a single 503 from Gemini ("high demand")
 * or one dropped socket surfaced to the user as «فشل الاتصال بالعقل: network
 * error» — the whole turn died on a blip that a 400 ms retry would have ridden
 * out. Free tiers are *expected* to blip, so a blip must not be fatal.
 *
 * Only transient classes are retried (5xx, 429, timeout, socket). A 401/403 or a
 * retired model id is NOT retried here — those are handled by the caller, which
 * knows how to heal or disable the provider.
 */
function isTransient(message: string): boolean {
  return /\b(429|500|502|503|504)\b|high demand|temporar|timeout|timed out|ECONNRESET|ETIMEDOUT|EAI_AGAIN|socket hang up|network error|fetch failed|empty response/i.test(
    message,
  );
}

async function attemptWithRetry(
  attempt: (model: string) => Promise<string>,
  model: string,
  tries = 3,
): Promise<string> {
  let lastErr: unknown;
  for (let i = 0; i < tries; i++) {
    try {
      return await attempt(model);
    } catch (err) {
      lastErr = err;
      const msg = String((err as Error).message ?? "");
      if (!isTransient(msg) || i === tries - 1) throw err;
      // 400 ms, 900 ms — short enough that the user does not notice, long
      // enough for a rate-limit window to reopen.
      await new Promise((r) => setTimeout(r, 400 * (i + 1) + 100 * i));
    }
  }
  throw lastErr;
}

/**
 * One completion with self-correction: if the model id is rejected, discover a
 * working one, retry once, and keep it for the life of the process.
 */
export async function completeWithProvider(
  provider: LlmProviderInfo,
  messages: LlmMessage[],
  opts: { temperature?: number; maxTokens?: number; timeoutMs?: number } = {},
): Promise<{ text: string; model: string; ms: number; healed?: boolean }> {
  const started = Date.now();
  const model = await resolveModel(provider);

  const attempt = async (useModel: string): Promise<string> =>
    provider.kind === "ollama"
      ? callOllama({ ...provider, model: useModel }, messages, opts.temperature)
      : callOpenAiCompatible({ ...provider, model: useModel }, messages, opts.temperature, opts.maxTokens, opts.timeoutMs);

  const rejected = AUTH_REJECTED.get(provider.id);
  if (rejected) throw new Error(`${provider.id}: المفتاح مرفوض (${rejected}) — تم تجاهله`);

  try {
    const text = await attemptWithRetry(attempt, model);
    return { text, model, ms: Date.now() - started };
  } catch (err) {
    const msg = String((err as Error).message ?? "");

    if (isAuthRejection(msg)) {
      AUTH_REJECTED.set(provider.id, msg.slice(0, 90));
      logger.warn({ provider: provider.id }, "llm: key rejected — provider disabled for this process");
      throw err;
    }

    // A retired model id: ask the provider what it serves, then retry there.
    if (isModelRejection(msg)) {
      const healedModel = await discoverModel(provider);
      if (healedModel && healedModel !== model) {
        logger.warn({ provider: provider.id, from: model, to: healedModel }, "llm: model retired, auto-switched");
        const text = await attempt(healedModel);
        MODEL_CACHE.set(provider.id, healedModel);
        return { text, model: healedModel, ms: Date.now() - started, healed: true };
      }
      throw err;
    }

    // A rate-limited free model is not a broken provider: the next free one on
    // the same key usually answers immediately.
    if (isRateLimited(msg)) {
      const candidates = (await discoverModelList(provider)).filter((id) => id !== model).slice(0, 3);
      for (const alt of candidates) {
        try {
          const text = await attempt(alt);
          MODEL_CACHE.set(provider.id, alt);
          logger.warn({ provider: provider.id, from: model, to: alt }, "llm: rate-limited model, switched");
          return { text, model: alt, ms: Date.now() - started, healed: true };
        } catch {
          continue;
        }
      }
    }
    throw err;
  }
}

/** Chat-capable models for a provider, preference-ordered, de-duplicated. */
async function discoverModelList(provider: LlmProviderInfo): Promise<string[]> {
  const available = (await listProviderModels(provider)).filter((id) => !NOT_CHAT.test(id));
  const pref = MODEL_PREFERENCE[provider.id] ?? [];
  const ordered: string[] = [];
  for (const wanted of pref) {
    for (const id of available) {
      if (id.toLowerCase().includes(wanted.toLowerCase()) && !ordered.includes(id)) ordered.push(id);
    }
  }
  for (const id of available) if (!ordered.includes(id)) ordered.push(id);
  return ordered;
}

/** Model ids this key can actually use (for the panel / diagnostics). */
export async function availableModelsFor(providerId: string): Promise<string[]> {
  const providers = await listConfiguredProviders();
  const provider = providers.find((p) => p.id === providerId);
  if (!provider) return [];
  return (await listProviderModels(provider)).filter((id) => !NOT_CHAT.test(id));
}

async function callOpenAiCompatible(
  provider: LlmProviderInfo,
  messages: LlmMessage[],
  temperature = 0.6,
  maxTokens = 1400,
  timeoutMs = TIMEOUT_MS,
): Promise<string> {
  const res = await fetch(chatUrl(provider), {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...authHeaders(provider),
    },
    body: JSON.stringify({
      model: provider.model,
      messages,
      temperature,
      max_tokens: maxTokens,
    }),
    signal: AbortSignal.timeout(timeoutMs),
  });
  if (!res.ok) {
    const body = await res.text().catch(() => "");
    throw new Error(`${provider.id} HTTP ${res.status}: ${body.slice(0, 160)}`);
  }
  const data = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
  const text = data.choices?.[0]?.message?.content ?? "";
  if (!text.trim()) throw new Error(`${provider.id}: empty response`);
  return text;
}

async function callOllama(provider: LlmProviderInfo, messages: LlmMessage[], temperature = 0.6): Promise<string> {
  const res = await fetch(`${provider.baseUrl}/api/chat`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "ngrok-skip-browser-warning": "1" },
    body: JSON.stringify({
      model: provider.model,
      messages,
      stream: false,
      options: { temperature, num_predict: 1400 },
    }),
    signal: AbortSignal.timeout(TIMEOUT_MS),
  });
  if (!res.ok) throw new Error(`ollama HTTP ${res.status}`);
  const data = (await res.json()) as { message?: { content?: string }; response?: string };
  const text = data.message?.content ?? data.response ?? "";
  if (!text.trim()) throw new Error("ollama: empty response");
  return text;
}

/**
 * Ask the first working provider. Returns null when no model is reachable —
 * the caller then uses the deterministic planner (agent still fully works).
 */
export async function llmComplete(
  messages: LlmMessage[],
  opts: { temperature?: number; maxTokens?: number; prefer?: string } = {},
): Promise<LlmResult | null> {
  const providers = await listConfiguredProviders();
  logger.info({ providers: providers.map((p) => `${p.id}:${p.baseUrl}`) }, "llm: providers resolved");
  const ordered = opts.prefer
    ? [...providers.filter((p) => p.id === opts.prefer), ...providers.filter((p) => p.id !== opts.prefer)]
    : providers;

  for (const provider of ordered) {
    const started = Date.now();
    logger.info({ provider: provider.id, kind: provider.kind }, "llm: attempt");
    try {
      const out = await completeWithProvider(provider, messages, {
        temperature: opts.temperature,
        maxTokens: opts.maxTokens,
      });
      logger.info({ provider: provider.id, model: out.model, healed: out.healed, ms: Date.now() - started }, "llm: success");
      return { text: out.text, provider: provider.id, model: out.model, ms: Date.now() - started };
    } catch (err) {
      // Trying the next provider is a normal path (Ollama off, quota, offline…).
      logger.debug(
        { provider: provider.id, err: String((err as Error).message).slice(0, 120), ms: Date.now() - started },
        "llm provider unavailable",
      );
    }
  }
  return null;
}

/** Extract the first JSON object from a model reply (tolerates ``` fences). */
export function extractJson<T = unknown>(text: string): T | null {
  if (!text) return null;
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  const candidate = fenced ? fenced[1] : text;
  const start = candidate.indexOf("{");
  const end = candidate.lastIndexOf("}");
  if (start < 0 || end <= start) return null;
  try {
    return JSON.parse(candidate.slice(start, end + 1)) as T;
  } catch {
    return null;
  }
}
