import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from "react";
import type { PlatformControlSnapshot } from "../lib/standalone-api";

export interface SystemEvent {
  type: string;
  ts: number;
  data?: Record<string, unknown>;
}

export interface MemoryEvent {
  id: string;
  memoryType: string;
  key: string;
  content: string;
  ts: number;
  importance?: number;
  createdAt?: string | number;
  tags?: string;
}

export interface AutonomousStatus {
  enabled: boolean;
  tasksCompleted: number;
  tasksErrored: number;
  isRunning: boolean;
}

interface SystemContextValue {
  autonomousStatus: AutonomousStatus;
  systemEvents: SystemEvent[];
  memoryEvents: MemoryEvent[];
  platformSnapshot: PlatformControlSnapshot | null;
  enableAutonomous: () => void;
  disableAutonomous: () => void;
  runAutonomousTask: (prompt: string) => Promise<void>;
  refreshAll: () => void;
}

const DEFAULT_STATUS: AutonomousStatus = { enabled: false, tasksCompleted: 0, tasksErrored: 0, isRunning: false };

function isPlatformControlSnapshot(value: unknown): value is PlatformControlSnapshot {
  if (typeof value !== "object" || value === null) return false;
  const snapshot = value as Record<string, unknown>;
  return (
    typeof snapshot.ok === "boolean" &&
    typeof snapshot.online === "boolean" &&
    typeof snapshot.status === "string" &&
    typeof snapshot.iqScore === "number" &&
    typeof snapshot.connected === "boolean" &&
    typeof snapshot.ts === "string" &&
    Array.isArray(snapshot.activeProcesses)
  );
}

async function fetchPlatformSnapshot(): Promise<PlatformControlSnapshot> {
  const response = await fetch("/api/platform/snapshot");
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  const payload: unknown = await response.json();
  if (!isPlatformControlSnapshot(payload)) {
    throw new Error("Invalid platform snapshot response");
  }
  return payload;
}

const SystemContext = createContext<SystemContextValue>({
  autonomousStatus: DEFAULT_STATUS,
  systemEvents: [],
  memoryEvents: [],
  platformSnapshot: null,
  enableAutonomous: () => {},
  disableAutonomous: () => {},
  runAutonomousTask: async () => {},
  refreshAll: () => {},
});

export function SystemProvider({ children }: { children: ReactNode }) {
  const [autonomousStatus, setAutonomousStatus] = useState<AutonomousStatus>(DEFAULT_STATUS);
  const [systemEvents, setSystemEvents] = useState<SystemEvent[]>([]);
  const [memoryEvents, setMemoryEvents] = useState<MemoryEvent[]>([]);
  const [platformSnapshot, setPlatformSnapshot] = useState<PlatformControlSnapshot | null>(null);

  const addEvent = useCallback((type: string, data?: Record<string, unknown>) => {
    setSystemEvents(prev => [{ type, ts: Date.now(), data }, ...prev].slice(0, 200));
  }, []);

  const setAutonomousMode = useCallback(async (enabled: boolean) => {
    try {
      const response = await fetch(`/api/autonomous/${enabled ? "enable" : "disable"}`, { method: "POST" });
      const result = (await response.json()) as {
        ok?: boolean;
        error?: string;
        status?: { enabled?: boolean; daemon?: { running?: boolean; cycles?: number } };
      };
      if (!response.ok || result.ok !== true) {
        throw new Error(result.error || `HTTP ${response.status}`);
      }
      const actualEnabled = result.status?.enabled;
      if (typeof actualEnabled !== "boolean") {
        throw new Error("Autonomy response omitted its measured enabled state");
      }
      setAutonomousStatus((status) => ({
        ...status,
        enabled: actualEnabled,
        isRunning: Boolean(result.status?.daemon?.running),
        tasksCompleted: Number(result.status?.daemon?.cycles ?? status.tasksCompleted),
      }));
      addEvent(actualEnabled ? "autonomous_enabled" : "autonomous_disabled");
    } catch (error) {
      addEvent(enabled ? "autonomous_enable_failed" : "autonomous_disable_failed", {
        error: error instanceof Error ? error.message : String(error),
      });
    }
  }, [addEvent]);

  const enableAutonomous = useCallback(() => setAutonomousMode(true), [setAutonomousMode]);
  const disableAutonomous = useCallback(() => setAutonomousMode(false), [setAutonomousMode]);

  const runAutonomousTask = useCallback(async (prompt: string) => {
    setAutonomousStatus((status) => ({ ...status, tasksErrored: status.tasksErrored + 1 }));
    addEvent("task_error", {
      prompt: prompt.slice(0, 100),
      error: "لا يوجد مشغّل مهام سريع حقيقي لهذا المسار؛ لم تُنفذ المهمة.",
    });
  }, [addEvent]);

  const refreshAll = useCallback(() => {
    addEvent("refresh");
    void fetch("/api/memory?limit=50").then(r => r.json()).then((d: MemoryEvent[] | { entries?: MemoryEvent[]; memories?: MemoryEvent[] }) => {
      // /api/memory answers with a bare array on the in-memory store and with
      // { entries } / { memories } on other deployments — support all of them.
      const list = Array.isArray(d) ? d : (d?.entries ?? d?.memories);
      if (list) setMemoryEvents(list);
    }).catch(() => addEvent("memory_refresh_failed"));
    void fetchPlatformSnapshot()
      .then(setPlatformSnapshot)
      .catch(() => addEvent("platform_snapshot_refresh_failed"));
  }, [addEvent]);

  useEffect(() => {
    void fetchPlatformSnapshot()
      .then(setPlatformSnapshot)
      .catch(() => addEvent("platform_snapshot_unavailable"));

    void fetch("/api/autonomous/status")
      .then(async (response) => {
        if (!response.ok) throw new Error(`HTTP ${response.status}`);
        return (await response.json()) as {
          ok?: boolean;
          enabled?: boolean;
          daemon?: { running?: boolean; cycles?: number };
        };
      })
      .then((status) => {
        if (status.ok !== true || typeof status.enabled !== "boolean") {
          throw new Error("Invalid autonomy status response");
        }
        const enabled = status.enabled;
        setAutonomousStatus((current) => ({
          ...current,
          enabled,
          isRunning: Boolean(status.daemon?.running),
          tasksCompleted: Number(status.daemon?.cycles ?? current.tasksCompleted),
        }));
      })
      .catch(() => addEvent("autonomous_status_unavailable"));

    const es = new EventSource("/api/agent/events");
    es.onmessage = (ev) => {
      try {
        const d = JSON.parse(ev.data as string) as { type?: string; [key: string]: unknown };
        addEvent(d.type ?? "event", d);
        if (d.type === "platform_snapshot" && isPlatformControlSnapshot(d.snapshot)) {
          setPlatformSnapshot(d.snapshot);
        }
        if (d.type === "memory_saved") {
          setMemoryEvents(prev => [{
            id: String(d.id ?? Date.now()),
            memoryType: String(d.memoryType ?? "fact"),
            key: String(d.key ?? ""),
            content: String(d.content ?? ""),
            ts: Date.now(),
            importance: Number(d.importance ?? 0),
          }, ...prev].slice(0, 200));
        }
        if (d.type === "task_completed") {
          setAutonomousStatus(s => ({ ...s, tasksCompleted: s.tasksCompleted + 1 }));
        }
        if (d.type === "task_error") {
          setAutonomousStatus(s => ({ ...s, tasksErrored: s.tasksErrored + 1 }));
        }
      } catch { /* ignore */ }
    };
    return () => es.close();
  }, [addEvent]);

  return (
    <SystemContext.Provider value={{ autonomousStatus, systemEvents, memoryEvents, platformSnapshot, enableAutonomous, disableAutonomous, runAutonomousTask, refreshAll }}>
      {children}
    </SystemContext.Provider>
  );
}

export function useSystem() {
  return useContext(SystemContext);
}
