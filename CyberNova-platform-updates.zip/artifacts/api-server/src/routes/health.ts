import { Router, type IRouter } from "express";
import { getPlatformControlSnapshot } from "../lib/standalone-api";
import { getConnectedAgentList } from "./local-agent";

const router: IRouter = Router();

function summarizePlatform() {
  const snapshot = getPlatformControlSnapshot();
  const agents = getConnectedAgentList();
  const configuredTarget = Number(process.env.NOVA_FLEET_AGENTS);
  const targetAgents =
    Number.isSafeInteger(configuredTarget) && configuredTarget > 0 ? configuredTarget : 10;
  return {
    ok: true,
    online: snapshot.online,
    status: snapshot.status,
    connected: agents.length > 0,
    iq: snapshot.iq,
    iqScore: snapshot.iqScore,
    level: snapshot.level,
    ts: snapshot.ts,
    memory: {
      count: snapshot.memoryCount,
      knowledgeItems: snapshot.knowledgeItems,
      memories: snapshot.memories,
    },
    fleet: {
      totalAgents: agents.length,
      onlineAgents: agents.length,
      targetAgents,
      targetMet: agents.length >= targetAgents,
      machines: agents.map((agent) => ({
        id: String(agent.id ?? "agent"),
        hostname: String(agent.hostname ?? "unknown"),
        platform: String(agent.platform ?? "unknown"),
        status: "online",
        connectedAt: agent.connectedAt ?? Date.now(),
      })),
    },
    platform: snapshot,
  };
}

router.get("/healthz", (_req, res) => {
  const snapshot = getPlatformControlSnapshot();
  res.json({
    status: "ok",
    online: snapshot.online,
    platform: "CyberNova",
    statusText: snapshot.status,
    iq: snapshot.iq,
    connected: snapshot.connected,
    ts: snapshot.ts,
  });
});

router.get("/status", (_req, res) => {
  res.json(getPlatformControlSnapshot());
});

router.get("/platform/snapshot", (_req, res) => {
  res.json(getPlatformControlSnapshot());
});

router.get("/platform/summary", (_req, res) => {
  res.json(summarizePlatform());
});

router.get("/health", (_req, res) => {
  const snapshot = getPlatformControlSnapshot();
  res.json({
    ok: true,
    service: "cybernova-api",
    online: snapshot.online,
    status: snapshot.status,
    iq: snapshot.iq,
    connected: snapshot.connected,
    ts: snapshot.ts,
  });
});

export default router;
