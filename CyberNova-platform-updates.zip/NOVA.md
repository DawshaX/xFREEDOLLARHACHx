# NOVA — عقل منصة CyberNova (دليل سريع بالعربي)

> **باختصار:** دلوقتي بقى عندك شات حقيقي جوّه البرنامج. تكتبله بالعامية، هو يفهم، يعمل خطة،
> ينفّذ أدوات حقيقية على المنصة، وكل خطوة بتظهر قدامك لحظة بلحظة. مجاني 100% وملكك بالكامل.

---

## 1) فين ألاقيه؟

| الواجهة | الرابط | الاستخدام |
|---|---|---|
| **NOVA Core (الشات الجديد)** | `/nova-core` | الشات الأساسي + شريط تنفيذ حي (تايم لاين) |
| **ذاكرة نوفا** | `/nova-memory` | ذاكرتها طويلة الأمد: عرض، بحث، تثبيت، حذف، تصدير/استيراد |
| Live Agent Panel (الديسكتوب) | `/live-agent` | نفس العقل داخل نافذة الديسكتوب |
| API مباشر | `/api/nova-core/*` | للربط من أي أداة خارجية |

الشات الجديد موجود في القائمة الجانبية تحت **«العمليات العصبية»** باسم
**NOVA Core · المحادثة**.

---

## 2) التشغيل بأمر واحد (جهازك)

```bash
./scripts/nova-local.sh --ollama
```

بيعمل الآتي لوحده:
1. يتأكد من Node و pnpm (وينصّب لو ناقص).
2. يبني الـ API والواجهة لو مش مبنيين.
3. يشغّل السيرفر على `:8080` (ده العقل + 21 أداة حقيقية).
4. يشغّل الواجهة على `:3000` (أي `/api` بيتحوّل تلقائي للسيرفر).
5. يقولك Ollama شغال ولا لأ.

بعد كده افتح: <http://localhost:3000/nova-core>

للإيقاف: `Ctrl + C` (بيقفل الاتنين مع بعض).

---

## 3) تشغيل العقل المجاني (Ollama)

```bash
# 1. نصّب Ollama مرة واحدة من https://ollama.com/download
# 2. نزّل موديل مجاني
ollama pull llama3.1          # أو qwen2.5:7b أو mistral
# 3. اسمح للمتصفح يتكلم مع Ollama (مهم جدًا)
#    macOS / Linux:
OLLAMA_ORIGINS=* ollama serve
#    Windows (PowerShell):
setx OLLAMA_ORIGINS *
# 4. شغّل المنصة
./scripts/nova-local.sh --ollama
```

لو مفيش Ollama خالص؟ **المنصة بتشتغل برضه.** العقل المدمج (Built-in Planner) بيفهم العربي،
بيرتّب الخطة، وبينفّذ نفس الأدوات الحقيقية — الفرق بس إن الكلام بيكون قوالب جاهزة مش كتابة حرة.

### مفاتيح سحابية مجانية (اختياري)
لو حبيت جودة أعلى ببلاش، حطّ أي مفتاح من دول في البيئة، والمنصة هتستخدمه تلقائيًا لو Ollama مقفول:

```
GROQ_API_KEY=...        # الأسرع في الفري تير
OPENROUTER_API_KEY=...  # موديلات :free
GEMINI_API_KEY=...
MISTRAL_API_KEY=...
TOGETHER_API_KEY=...
```

شوف القالب: `artifacts/api-server/.env.nova.example`

---

## 4) هو بيعمل إيه فعليًا؟ (مش كلام)

**29 أداة حقيقية** على السيرفر:

- **استطلاع:** `recon_target` (DNS + TLS + ترويسات في نداء واحد)، `dns_lookup`، `tls_audit`، `http_headers_audit`
- **سطح الهجوم:** `port_scan` (محدود)، `subdomain_enum`، `web_fetch`
- **استخبارات:** `cve_lookup` (NVD)، `vuln_search`، `exploit_search` (Exploit-DB)، `github_search`، `knowledge_search` (فهرس المنصة 3,300+ نمط)، `kali_toolbox` (78 أداة)
- **ذاكرة ومهام:** `memory_save` / `memory_search` / `memory_list`، `set_active_target`، `record_finding`، `mission_status`
- **تقارير ومهام:** `mission_create`، `report_generate` (تقرير Markdown جاهز للإرسال)، `evidence_list`، `report_list`
- **منصة:** `platform_status`، `hash_text`، `corpus_stats`، `task_list`
- **اختياري (مقفول افتراضيًا):** `run_shell` — بيتفتح بس لو أنت حطيت `ENABLE_AGENT_SHELL=1`

كل نتيجة بترجع من الأداة نفسها — مفيش بيانات مخترعة. وكل أداة في التايم لاين ليها زر
**«افتح الصفحة»** بيوديك للشاشة الخاصة بيها جوه المنصة.

### حواجز الأمان
- أي أداة بتشتغل على نطاق **داخلي/خاص** (127.0.0.1، 10.x، 192.168.x…) بتترفض → حماية من SSRF.
- `run_shell` مش متاح غير بإذن صريح منك.
- الأدوات النشطة معلّمة بلون مختلف (`active` / `risky`) قبل التنفيذ.

---

## 5) لما مفيش سيرفر (GitHub Pages / فتح الملف مباشرة)

الشات بيشتغل برضه بالمخ المحلي، وبأدوات بتشتغل جوه المتصفح:

| الأداة | بتعمل إيه فعليًا |
|---|---|
| `dns_lookup` | استعلام DNS حقيقي عبر DNS-over-HTTPS (A / MX / TXT / NS) |
| `cve_lookup` | بحث حقيقي في **NVD** مباشرة |
| `github_search` | بحث حقيقي في GitHub API |
| `web_check` | اختبار وصول الموقع وزمن استجابته |
| `knowledge_search` | فهرس المنصة المحلي |
| `memory_save` / `memory_list` | ذاكرة دائمة على جهازك (localStorage) |
| `set_active_target` | تحديد الهدف النشط |

ولو عندك Ollama شغال، الرد نفسه بيتكتب بالموديل بشخصية NOVA.

**ليه مش نفس الـ 21؟** المتصفح مش بيقدر يعمل فحص منافذ أو TLS أو تعداد نطاقات — دي
محتاجة السيرفر. ولهذا الشات بيقولك بوضوح: «أنا بالمخ المحلي» ويقترح تشغيل السيرفر.

---

## 6) الـ API (لو حبيت تربط حاجة تانية)

```
GET  /api/nova-core/status    →  هوية نوفا + حالة العقل + عدد الأدوات
GET  /api/nova-core/tools     →  كتالوج الأدوات كامل (JSON Schema)
GET  /api/nova-core/persona   →  بطاقة الشخصية
POST /api/nova-core/chat      →  SSE stream: ready → thought → plan → tool_call → tool_result → delta → done
POST /api/nova-core/execute   →  تشغيل أداة واحدة مباشرة  { "tool": "dns_lookup", "args": {...} }
```

مثال سريع:

```bash
curl -N -X POST http://localhost:8080/api/nova-core/chat \
  -H 'content-type: application/json' \
  -d '{"message":"اعمل استطلاع على github.com"}'
```

---

## 6.5) الذاكرة طويلة الأمد — إزاي بتشتغل

دي الحاجة اللي بتخليها **تفهم وتحفظ** بدل ما تبدأ من الصفر كل محادثة.

**التخزين:** ملف واحد على القرص `state/nova-memory.json` (أو `NOVA_MEMORY_FILE`).
الكتابة ذرّية (ملف مؤقت ثم rename) فمستحيل يتلف الملف لو السيرفر وقع في نص الكتابة.

**5 أنواع ذاكرة:**

| النوع | بيحفظ إيه | مثال |
|---|---|---|
| `fact` | حقائق ثابتة | «برنامجي على HackerOne اسمه acme» |
| `preference` | أسلوبك وتفضيلاتك | «التقارير بالعربي ومختصرة» |
| `lesson` | نتيجة أداة/درس | «hackerone.com ناقصه permissions-policy» |
| `event` | حدث تشغيلي | «شغّلت استطلاع الساعة كذا» |
| `session` | ملخص محادثة كاملة | سؤالك + الأدوات + الرد |

**الاسترجاع قبل كل رد:** نوفا بتحسب صلة كل ذكرى بسؤالك (تطابق الكلمات + الأهمية +
الحداثة + نفس الهدف + المثبتة) وبتضيف أقرب 8 ذكريات + تفضيلاتك + أهم الدروس
داخل الـ System Prompt. يعني **بتفتكر تلقائياً بدون ما تطلب**.

**التنظيم:** كل ذكرى ليها `scope` (النطاق/الهدف). الذكريات المتعلقة بنفس النطاق بتتفوق في الترتيب.

**الحماية من التضخم:** كل نوع ليه سقف، والأقل أهمية والأقدم بيتشال تلقائياً. المثبتة (`pinned`) عمرها ما بتتشال.

**الأدوات الجديدة:** `memory_save` · `memory_search` · `memory_list` · `memory_forget` · `memory_stats`
(إجمالي الأدوات بقى **29**).

**أمثلة تجربها:**
```
احفظ اني افضل التقارير بالعربي وباسلوب مختصر دايماً
تفتكر ايه عن برنامجي؟
ايه الدروس اللي اتعلمتها من hackerone.com؟
```

**التحكم اليدوي:** صفحة `/nova-memory` — تبحث، تثبت، تحذف، تصدّر نسخة احتياطية، أو تستورد.

---

## 6.6) تشغيل دائم 24/7 مجاناً (بدون جهازك)

| الطريقة | الملف | ملاحظات |
|---|---|---|
| **Oracle Cloud Always Free** | `deploy/oracle-setup.sh` | 🥇 سيرفر حقيقي مجاني للأبد، مش بينام، يشيل Ollama |
| **Render** | `render.yaml` | أسهل بداية، بينام بعد 15 دقيقة (الـ Action بيصحّيه) |
| **Fly.io** | `fly.toml` | تشغيل مستمر + قرص دائم للذاكرة |
| **Docker** | `Dockerfile` + `docker-compose.yml` | أي مكان، `--profile local-ai` يضيف Ollama |
| **PM2** | `ecosystem.config.cjs` | أي جهاز/سيرفر، بدون root |
| **systemd** | جوّه `oracle-setup.sh` | يرجع لوحده + يبدأ مع البوت |

كل التفاصيل خطوة بخطوة: **[`deploy/README.md`](deploy/README.md)**

**الحاجات اللي بتشتغل لوحدها:**
- ✅ السيرفر يرجع تلقائياً لو وقع (`Restart=always`)
- ✅ يبدأ مع تشغيل الجهاز (`systemctl enable`)
- ✅ نسخة احتياطية يومية للذاكرة + GitHub Action احتياطي
- ✅ نبضة كل 10 دقايق تمنع النوم على الاستضافات المجانية
- ✅ موديل Ollama ينزل تلقائي أول تشغيل (`ensureOllamaReady`)
- ✅ لو مفيش موديل ولا مفتاح → العقل المدمج يكمّل الشغل

---

## 7) الشخصية

الشخصية والعقل مكتوبين في `artifacts/api-server/src/lib/agent/persona.ts` —
هوية، بروتوكول تفكير، لغة (مصري بسيط)، خطوط حمراء (مفيش تخريب، مفيش اختراق بدون إذن،
مفيش اختراع بيانات). عدّل فيه وزوّد اللي تحبه، وبعدها أعد بناء السيرفر.

---

## 8) أول 3 أسئلة تجربها

1. `مين انت وممكن تعمل ايه؟`
2. `اعمل استطلاع على github.com`
3. `ابحث عن CVE-2024-3094 وقولي الخطورة والحل`

---

## 9) محرك التنفيذ الحقيقي — Ops (`/api/ops/*`)

> الفرق عن باقي المنصة: ده مش عرض ولا محاكاة. **job حقيقي** بيشتغل على هدف **مصرّح به**،
> بمعدل آمن، ويكتب **أدلة مرفوصة بـ SHA-256**، ومفيش نتيجة تدخل التقرير غير بعد ما تعدّي على **بوابة البرهان**.

### الدورة الكاملة

```
تسجيل البرنامج (scope)  →  jobCreate  →  مهام حقيقية  →  findings + أدلة  →  verify  →  تقرير
     /api/ops/programs      /ops/jobs      state/jobs/<id>/     evidence/*.txt    501?     report.md
```

### 1) البوابة (`state/programs.json`)
أي مهمة **نشطة** على نطاق مش جوه برنامج مفعّل = **مرفوضة من الكود** (مش من البرومبت):
wildcard / exact / CIDR / `out_of_scope` / `passive_only` / سقف `max_rps` و `max_concurrency`.
العناوين الداخلية (127./10./192.168./169.254./::1/localhost) مرفوضة دائماً + إعادة تحقق من الـDNS (حماية SSRF/rebinding).

```bash
# أضف برنامج من السيرفر (يحتاج NOVA_EXEC_TOKEN)
curl -X POST http://localhost:8080/api/ops/programs \
  -H "x-nova-token: $NOVA_EXEC_TOKEN" -H 'content-type: application/json' \
  -d '{"id":"acme","name":"Acme Inc","platform":"hackerone","hosts":["*.acme.com"],"max_rps":1}'
```

### 2) أنواع المهام
| المدمج (بيشتغل في أي حتة) | أداة حقيقية (محتاجة النود/نود متصل) |
|---|---|
| `recon.dns` · `recon.tls` · `recon.headers` · `recon.ports` (≤40) | `tools.nuclei` (`-json`) · `tools.httpx` |
| `recon.certspotter` (سلبي) · `recon.securitytxt` · `recon.jspaths` | `tools.subfinder` · `tools.katana` · `tools.nmap` |
| `intel.cvebytech` (NVD على التقنية المكتشفة) | التثبيت من `/api/installer/tools` |

القاعدة: **طلب فاشل ≠ ثغرة**. لو الطلب ما وصلش، المهمة بتترجّع `failed` والسبب، ومش بتولّد finding.

### 3) نوفا بتستخدمه كأدوات
`scope_check` · `program_add` · `program_list` · `job_create` · `job_status` · `job_list` · `job_control` ·
`finding_verify` · `findings_list` · `job_report` · `ops_kinds` — يعني تقوله:
> «ادخل على برنامج acme واعمل استطلاع كامل وقولي لقيت إيه»
فيردّ بالـjob الحي ويكمل معاك.

### 4) الأمان بقى بوابة واحدة
مسار جديد `src/lib/ops/gate.ts` بيحكم على **كل** حاجة خطرة: `/api/local-agent/*` (exec/pty/fs/screenshot/ماوس-كيبورد)،
`/api/kill-switch`، `/api/nova-core/restart|auto-update|storage|execute`، اعتماد بث `/api/fleet/broadcast`،
`download-project-zip`، وتسجيل الوكلاء على WebSocket. موافقات `/api/nova-core/chat` القادمة من العميل لا تُعتمد؛
الأدوات الحساسة تظل محجوبة إلى أن يتوفر مسار موافقة موثّق مرتبط بالجلسة.
- `NOVA_EXEC_TOKEN` موجود → التوكن مطلوب (هيدر `x-nova-token` أو `?token=`).
- مفيش توكن → كتابة من اللوحة بس (same-origin)، و`curl` من برّه ياخد 403.
- `NOVA_OPEN_OPS=1` → الوضع المفتوح (معامل محلي فقط).
- تسجيل وكيل من غير توكن → **401** (الـWebSocket مفيش فيه إشارة أصلية تثق فيها).
- الـdaemon المستقل متوقف افتراضياً؛ تفعيله يحتاج `NOVA_AUTONOMOUS_DAEMON=1`.
- مسارات المنسّق ومستكشف المعرفة ومشغّل الخطوات التركيبي ترجع `501` بدل ما تعرض نتائج أو تنفيذ غير حقيقي.

### 5) متغيرات جديدة
| المتغير | الافتراضي | للتحكم في إيه |
|---|---|---|
| `NOVA_EXEC_TOKEN` | فارغ | مفتاح كل الكتابة والتنفيذ |
| `NOVA_PROGRAMS_FILE` | `state/programs.json` | سجل البرامج المصرّح بها |
| `NOVA_JOBS_REL` | `state/jobs` | مكان الـjobs والأدلة |
| `NOVA_ALLOW_NODE_TOOLS` | `1` | تشغيل الأدوات على السيرفر نفسه |
| `NOVA_FORCE_LOCAL_TOOLS` | `0` | تجاهل النودات واشغل محلياً |
| `NOVA_MAX_INFLIGHT` | `4` | أقصى طلبات متزامنة كلها |
| `NOVA_DEFAULT_RPS` | `1` | السقف لو البرنامج ما حدّدش |
| `NOVA_ALLOW_SOURCE_DOWNLOAD` | `0` | يفعّل تنزيل مصدر المشروع |
| `NOVA_AUTONOMOUS_DAEMON` | `0` | تشغيل الـdaemon المستقل (اختياري؛ لا تفعّله قبل مراجعة نطاقه) |
| `NOVA_OPEN_OPS` | `0` | وضع المعمل المحلي |

`GET /api/ops/version` بيقول build إيه اللي شغال فعلاً (sha + عمر الـbundle + الأدوات الموجودة + وضع الدورة الخلفية) — ده أول أمر تعمله لأي هوست بعيد قبل ما تصدّق أي حاجة تانية.
| `NOVA_TOKEN` (للنود) | فارغ | التوكن اللي بيسمح لأي جهاز يسجل في الأسطول |
| `NOVA_KEYS_URL` / `NOVA_KEYS_FILE` | فارغ | مصدر مفاتيح مجاني وقت الإقلاع (https إجباري) |
| `NOVA_SCOPE_DOMAINS` | فارغ | نطاقات تتسجّل أوتوماتيك في وضع الاستطلاع |
| `NOVA_KEYLESS_SEATS` | `openai-fast,mistral,llama` | موديلات المجلس بدون مفاتيح |
| `NOVA_OPS_AUTONOMY` | `passive` | عمق الدورة الخلفية: `off`/`passive`/`standard`/`deep` |
| `NOVA_OPS_SWEEP_HOURS` | `6` | أقل فترة بين دورتين على نفس البرنامج |
| `NOVA_OPS_SWEEP_MAX_TASKS` | `10` | سقف مهام كل دورة |

### 6) فحص إن البوابة لسه شغالة
```bash
pnpm run ops:selftest      # 35 فحص: سكوب + CIDR + SSRF + التوكن + الثروتل + الأدلة + الاكتشاف
pnpm run typecheck:ratchet # مفيش أخطاء type جديدة

**اللي بيمنع الجودة تتاكل في CI:** البوابة الحقيقية (ratchet + self-test للسكوب جيت)
شغالة في `NOVA live audit → quality-gate` كل 6 ساعات، مش في شغل النشر — النشر على
Pages بيعمل `--no-frozen-lockfile` فلو `@types` اتحدّث وزاد خطأ واحد كان الموقع كله
بيقع. في الـworkflow بتاع النشر الرقم بيتعرض كـwarning بس. (حصل فعلاً 2026-11-02.)
```

### حدود صادقة للمحرك
- `recon.ports` بيعتمد على TCP connect — لو الشبكة/البروكسي بيقبل أي اتصال هتلاقي منافذ «مفتوحة» وهي مش كده.
  بوابة `finding_verify` بتعيد الاتصال تاني بس؛ أي نتيجة من نوع منفذ لازم تتأكد بأمر banner حقيقي قبل التقرير.
- `nuclei`/`nmap` محتاجين الأدوات على نفس النود أو نود متصل بالوكيل — من غيرها المهمة بتفشل بوضوح.
- `fs_write` و mouse/keyboard **مقفولان بالتوكن** افتراضياً ومش بيستدعيهم أي أداة نوفا.

### 7) التزويد الذاتي — الصفر اللي يشتغل من غير ما تفتح ملف
الفكرة: منصة مجانية مفيهاش إعدادات يدوية. أي حاجة كانت محتاجة يد human اتحوّلت لأمر واحد أو متغير بيئة.

| الحاجة | المتغير / الأمر | بيحصل إيه |
|---|---|---|
| مفاتيح من مصدر عندك | `NOVA_KEYS_URL=https://...` (أو `NOVA_KEYS_FILE=~/keys.json`) | وقت الإقلاع بيتقرا JSON زي `{"GROQ_API_KEY":"..."}` ويتحقن في البيئة. مفتاح موجود في البيئة بيفضل الأول، القيم مش بتتسجل في اللوجات، و`http://` مرفوض غير بـ `NOVA_KEYS_ALLOW_HTTP=1` |
| نطاقات تدخل البرنامج | `NOVA_SCOPE_DOMAINS=example.com,https://hackerone.com/foo` | بيتسجّل كل نطاق **passive_only** أوتوماتيك (security.txt + استنتاج المنصة + استبعاد admin/staging/internal) |
| حالة اللي اتعمل | `GET /api/ops/provision` | بيقول أسماء المفاتيح اللي اتحمّلت (مش قيمها) والنطاقات اللي اتسجّلت |
| إعادة من غير restart | `POST /api/ops/provision/reload` | بيقرأ المصدر تاني فوراً |
| تسجيل برنامج بالكلام | أداة نوفا `program_discover` · `POST /api/ops/programs/discover` | قول «اكتشف برنامج example.com» — يقرأ سياسة الموقع ويسجّله بنفسه |
| تركيب أداة ناقصة | `POST /api/tools/install {"tool":"nuclei"}` | بينزّل ProjectDiscovery من الـrelease الرسمي أو `apt` على النود، وبعدها الأدوات بتبان في `ops_kinds` |

**بوابة الفحص النشط مش أوتوماتيك، وده مقصود:** `discover` بيسجّل استطلاع بس. عشان يمسّ الخدمة لازم نص
الإذن بالحرف `I have written permission for <host>` يجي بعد ما المستخدم يقولها — لو اتكتب من غير تأكيد
البرنامج هيفضل مقفول. ده الخط اللي ماينفعش يتعدي: الفحص النشط على ملك حد تاني من غير إذن = جريمة،
ومش مسألة إعداد.

### 8) المجلس بقى حقيقي من غير أي مفتاح
`listConfiguredProviders()` كان بيرجع **مقعد واحد** بدون مفاتيح، فالمجلس كان بيقول «صوت واحد»
وماينتجش. الآن كل مقعد = موديل مستقل على نفس الطرفية المفتوحة:

```
ollama · pollinations:openai-fast · pollinations:mistral · pollinations:llama   ← 4 مقاعد، $0
```

تغيير القايمة: `NOVA_KEYLESS_SEATS="openai-fast,mistral"` · إطفاء كله: `NOVA_KEYLESS_LLM=0`.
مقاعد `pollinations:*` مش بتتأثر بـ `POLLINATIONS_MODEL` (لو اتطبّق على الكل هيبقى صوت واحد بيخاطب نفسه) —
بيشتغل بس لما يكون في مقعد keyless واحد.

**قاعدة الـ45 ثانية (متقاسة، مش تخمين):** الطبقة المجانية في pollinations بترد **رد واحد لكل 45 ثانية لكل IP**
وبترجع `HTTP 402 FREE_LIMIT`. عشان كده `councilMembers()` بيختار **مقعد لكل endpoint الأول** (لأن الاختلاف
الحقيقي بييجي من موزدلات مختلفة)، وبعدين يكمّل بمقاعد تانية من نفس الـhost لو مفيش مفاتيح — مع **تأخير 1.2 ثانية
بين كل مقعدين على نفس الهوست**، والخطأ بقى بيتسمّى «حد المعدل المجاني (مش مفتاح غلط)» بدل ما يخلّي الواحد
يروح يغيّر إعدادات وهو سليم.

### 9) النودات والتوكن (اقرأها لو أسطولك وقف)
البوابة بترفض تسجيل أي نود من غير توكن، لأن النود معناه شيل أوامر على جهاز.
- `nova-agent.js` بيبعت `NOVA_TOKEN` (أو `--token`) في الـhandshake (`?token=`) وفي الـregister.
- `deploy/oracle-setup.sh` بيولّد التوكن لوحده في `/etc/cybernova.env` (chmod 600) ويطبعه مرة واحدة.
- أسطول GitHub بياخده من Secret اسمه `NOVA_EXEC_TOKEN`، و**الأدوات النشطة مش متثبتة عليه**
  (IP بتاع GitHub = بلاغ = ضياع الحساب). الأدوات التقيلة على نودك الدائم بس.
- `NOVA_ALLOW` على نودات Actions = قايدة قراءة/استطلاع؛ لو فاضي النود بيبقى مفتوح على كل حاجة، فمابقاش فاضي.

## 10) المخ الواعي — `/nova-fleet` بقى مدير البرنامج مش واجهة

الصفحة دي كانت «خريطة أسطول حلوة». بقى وراؤها عضو حقيقي في السيرفر:
`GET /api/nova-core/awareness` (`src/lib/awareness.ts`) — **قراية واحدة، 16 مصدر، للقراءة بس**.

**العقد (اللي اتقيس النهاردة على المحرك فعلياً):**

```jsonc
{ "ok": true, "verdict": "alive|degraded|blind|asleep",
  "moodAr": "أنا نوفا: عقلي شغال على 4 مصدر · المجلس بيصوّت (4) · …",
  "vitals": { "uptimeSec": 15, "rssMb": 127, "load1": 0.93, "node": "v22.22.3", "pid": 1759 },
  "net":  { "outbound": true, "tlsBlocked": false, "hosts": [github, dns, nvd, hackerone] },
  "sites":[ { "id":"pages", "url":"https://dawshax.github.io/xFREEDOLLARHACHx/", "ok":true, "ms":41 }, … ],
  "organs":[ { "id":"brain|council|fleet|ops|scope|proof|throttle|memory|bus|net|background",
               "state":"up|partial|down", "says":"…", "fixAr":"الحل العملي بالعربي" }, … ],
  "counters": { "programs": {…}, "jobs": {…}, "councilSeats":4, "nodes":0, "kinds":13, … },
  "build": { "sha":"…", "opsRouter":true, "stale":{…} } }
```

**القواعد الليخلي القراية دي صادقة:**
- **`verdict` سُلَّم مش ألوان:** `blind` = مفيش أي مسار للخارج · `asleep` = لا عقل ولا نود ولا تصريح ·
  `degraded` = عضو واقع · `alive` = كله فوق. الـ`partial` **مش** تنزيل للدرجة: «مفيش نود متصل» و«مفيش
  متصفح سامع البث» حالات خمول طبيعية، وتسميتها «degraded» بتعلّم الناس تتجاهل البانر.
- **`blind` مش «شبكة» لو المشكلة ثقة:** لو كل المنافذ رجّعت فشل اعتماد شهادة (`UNABLE_TO_VERIFY…`)
  ده مسار موجود وثقة مقطوعة — بيتسجّل `tlsBlocked:true` و`partial` مع `fixAr` تقول `NODE_EXTRA_CA_CERTS`.
  اتقس فعلاً: في الـsandbox ده بالظبط كان بيقلب `blind` → بقى `degraded` بالسبب الصح.
- **مفيش كتابة خالص** في العضو ده: مفيش `POST`، مفيش تشغيل أدوات، مفيش أسماء أجهزة، مفيش قيم مفاتيح.
  كاش 3 ثواني عشان اللوحة بتسأل كل 6، وأي مصدر بيرمي استثناء بيترجّع `ok:false` بدل ما الصفحة تولّع 500.
- **من غير سيرفر (Pages) المتصفح بيقيس اللي يقدر عليه:** اللوحة نفسها + `state/programs.json` المنشور +
  منافذ الخروج المسموحة للمتصفح، وكل عضواً محتاج سيرفر بيتقال عليه **«معلومة ناقصة»** — مش صفر ومش أخضر.
  القاعدة: **رقم مقسوش = مش رقم.**

**غرفة العمليات (`NovaOpsRoom` في نفس الصفحة):** مربوطة بالعقد الحقيقي حرفياً —
`GET /ops/programs` · `POST /ops/programs/discover` · `POST /ops/programs/check` (بيعرض **سبب** الرفض كما هو:
`passive_only` / `out_of_scope` / `no_programs`) · `POST /ops/jobs` بعمق `passive|standard|deep` ·
`GET /ops/jobs[/:id]` · `POST /ops/jobs/:id/verify|pause|resume|cancel` · `GET /ops/jobs/:id/report` ·
`GET|POST /ops/sweep`. مفيش قرار أمان في المتصفح: البوابة في السيرفر، واللوحة بتعرض رفضها.

**سطح الصيد (`NovaHuntSurface`، نفس الصفحة/نفس الـtab):** `GET /ops/hunt/candidates` (مرشّحون من
الكتالوج مرتّبين بأجود استجابة — كل سطر بيوصل ومعه `consented:false` و`passive_only` و
`network_context_only:true`، فالـCIDR/IP سياق مش scope) · `POST /ops/hunt/plan {target}` (security.txt +
`suggestPlan` **من غير تسجيل** — طلب خطة مش إذن) · `GET /ops/findings[/status]` · `POST /ops/findings/sync`
(الخزانة الوحيدة للنتايج، مفتاحها من المحتوى فالتكرار مابيضاعفش) · `GET /ops/findings/:key/report-draft`
(**409** على أي نتيجة ماعدش إنتاجها — المسودة مستحيلة مش متعطّلة، والصفحة بتطبع سبب الرفض بحروفه).

**تغيير أمني لازم تعرفه (اتعمل معاه):** قرايات النتائج بقت حساسة — `GET /api/ops/programs` و`/api/ops/jobs*`
و`/api/ops/stats` محتاجين **نفس الأصل أو التوكن** (لأنها بتقول إيه النطاقات اللي شغال عليها وإيه اللي اتلقّى).
`/api/nova-core/awareness` و`/api/ops/version` و`/api/ops/kinds` **فاضلين مفتوحين** — دول حالة machine مش أسرار.
المصفوفة متقيسة على المحرك: من `Origin` غريب → 403، من اللوحة (same-origin) → 200، من Pages مع `x-nova-token` → 200.

**التوكن في اللوحة:** حقل صغير فوق غرفة العمليات، بيتخزن في `localStorage` وبيتبعت في هيدر `x-nova-token` بس —
مش في الـURL، مش في اللوجات، وبيترفض الطلب من غير ما يبان.

**اللي اتصلح في نفس الطريق (عشان «المدير» ميبقاش بيكلّم ثغرة):** `agentTools.ts` كان بيستعلم على
`cvesTable.cveId` و`ragFiles.kind` — العمودين اسمهم `id` و`mimeType`. أي `search_cve_local` أو `list_files`
على نظام فيه Postgres كان بيرمي استثناء. الرقم اتظبط: الـratchet نزل من 99 لـ**97** (والـbaseline اتقفل عليه).

**وعن المضيف المجاني:** الكتالوج بقى بيانات في المحرك (`src/lib/ops/free-hosts.ts`) — كل مورد فيه
`scanPolicy` (شروط الاستخدام بتاعته في إيه) و`status2026` (اللي موقعه قاله النهاردة) و`probeUrl`
اللي بيتقاس بيه. `GET /api/fleet/catalogue?probe=1` بيردّ بالادّعاء + القياس، وعضو `freehosts` في
قراية الوعي بيقول كام موقع بيردّ والأحسن دلوقتي. القصة الكاملة والوصفات: `docs/FREE-HOSTS-2026.md`.

**ولو عايز مكان واحد يغنيك عن السيرفرات كلها:** `docs/GITHUB-AS-THE-SERVER.md` —
الطابور في `state/nova-queue.json` و`nova-runner.yml` بيحوّل جهاز جيت-هَب (4 أنوية/16 جيجا
بـ`sudo`، بلا كارت، بلا نوم، دقائق غير محدودة على ريبو عام) لنود شغال بيفتح المحرك الحقيقي
وينفّذ من خلال `/api/ops/*` ويرجّع التقرير منشوراً على Pages. ده بيشتغل حتى لو كل المضيفين
واقعين — والعمق النشط متقفل افتراضياً لأن IP المصدر هنا بتاع جيت-هَب.

**وسؤال «طب شغالة كام في المية؟» بقى مقيس:** `docs/LIVE-VERIFY.md` — `scripts/verify-live.mjs`
بيشغّل nmap/nuclei/httpx/subfinder/katana/ffuf والأحد عشر نوع مهمة على أهداف أصحابها قالوا صراحة
«افحصوني» (scanme.nmap.org، testphp.vulnweb.com، demo.testfire.net)، ومعاه **سيطرة سلبية**: فحص
نشط على `example.com` لازم يترفض — لو عدّى، الحكم `UNSAFE` مش `RED`. `live-verify.yml` بيعمل ده
كل 6 ساعات على Actions وبيعمل commit لـ`state/verified-live.md`، وعضو `liveverify` في قراية الوعي
بيحكى النتيجة بتواريخها. مفيش ادعاء بيمر من غير سطر في التقرير.

**عايز مكان واحد بس؟** `render.yaml` بقى ينزّل الأدوات وقت الـbuild (`vendor/bin`: nuclei/httpx/
subfinder/katana/dnsx/naabu/ffuf من ريليساتها، من غير root ولا apt)، فالخدمة الواحدة على Render Free
بتشغّل المحرك + اللوحة على نفس العنوان + المجلس + jobs/أدلة/تقارير + مهام الأدوات. اللي مالوش:
`nmap` (استخدم `naabu`)، ديسك دائم، والضربة النشطة على أهداف البرامج — دي على نود روت.
الجدول بالتفصيل: `deploy/render-free-guide.md`.
